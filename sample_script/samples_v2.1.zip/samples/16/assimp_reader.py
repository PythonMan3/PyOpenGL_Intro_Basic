from OpenGL.GL import *
from OpenGL.GLU import *
import gl_util
import c_assimp
import my_glm as glm

class AssimpReader:
    def __init__(self, model_file):
        self.model = c_assimp.Model()
        self.model.import_file(model_file)
        
    def create_vao(self):
        for mat in self.model.materials:
            mat.vao = glGenVertexArrays(1)
            glBindVertexArray(mat.vao)
            glEnableVertexAttribArray(0)
            glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_vertex)
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
            if mat.has_normal:
                glEnableVertexAttribArray(1)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_normal)
                glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, None)
            if mat.has_uv:
                glEnableVertexAttribArray(2)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_tex_coord)
                glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, None)
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mat.ibo_faces)
            if mat.vbo_bone_id:
                glEnableVertexAttribArray(3)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_bone_id)
                glVertexAttribIPointer(3, 4, GL_UNSIGNED_INT, 0, None)
            if mat.vbo_bone_weight:
                glEnableVertexAttribArray(4)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_bone_weight)
                glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, 0, None)
            glBindBuffer(GL_ARRAY_BUFFER, 0)
            glBindVertexArray(0)
        
    def read_mesh(self):
        for mat in self.model.materials:
            # mesh
            mat.ibo_faces = gl_util.create_ibo(mat.faces)
            if mat.has_position:
                mat.vbo_vertex = gl_util.create_vbo(mat.vertexs)
            if mat.has_normal:
                mat.vbo_normal = gl_util.create_vbo(mat.normals)
            if mat.has_uv:
                mat.vbo_tex_coord = gl_util.create_vbo(mat.uvs)
            # texture
            if mat.texture_file:
                 mat.texture = gl_util.create_texture(mat.texture_file)
            # bone
            mat.vbo_bone_id = gl_util.create_ibo(mat.vertex_bone_idxs)
            mat.vbo_bone_weight = gl_util.create_vbo(mat.vertex_weights)
        # vao
        self.create_vao()
        
    def add_animation(self, anim):
        self.model.add_animation(anim)
        
    def calc_animate_vertexs(self):
        world = glm.mat4(1.0)
        self.model.animate_node(world)
        for i, mat in enumerate(self.model.materials):
            anim_verts = []
            for j in range(mat.num_vertex):
                x = mat.vertexs[j*3]
                y = mat.vertexs[j*3+1]
                z = mat.vertexs[j*3+2]
                pos = glm.vec4(0.0)
                for k in range(4):
                    joint_idx = mat.vertex_bone_idxs[j][k]
                    weight = mat.vertex_weights[j][k]
                    if weight > 0.0:
                        node_index = mat.node_indexs[joint_idx]
                        node = self.model.nodes[node_index]
                        vert_ = glm.vec4(x, y, z, 1.0)
                        pos_ = node.skinning_matrix * vert_ * weight
                        pos[0] += pos_[0]
                        pos[1] += pos_[1]
                        pos[2] += pos_[2]
                anim_verts.append([pos[0], pos[1], pos[2]])
                self.model.bound_box.add_point([pos[0], pos[1], pos[2]])
        return anim_verts
