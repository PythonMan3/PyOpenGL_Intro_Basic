from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import my_glm as glm
import cube_shader
import gl_util
from trackball import Trackball

vertex_shader_src="""
#version 400 core

in vec3 position;
in vec3 normal;
out vec3 outPosition;
out vec3 outNormal;
out vec4 outColor;
uniform mat4 MVP;

void main(void) {
    vec4 color = vec4(1.0, 0.0, 0.0, 1.0);
    outPosition = position;
    outNormal = normal;
    outColor = color;
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec3 outPosition;
in vec3 outNormal;
in vec4 outColor;
out vec4 outFragmentColor;
uniform mat4 invM;
uniform vec3 lightPosition;
uniform vec3 eyePosition;

void main(void) {
    vec4 ambientColor = vec4(0.1, 0.0, 0.0, 1.0);
    vec3 invLightPos = (invM * vec4(lightPosition, 1.0)).xyz;
    vec3 invLight = normalize(invLightPos - outPosition);
    vec3 invEyePos = (invM * vec4(eyePosition, 1.0)).xyz;
    vec3 invEye = normalize(invEyePos - outPosition);
    vec3 halfLE = normalize(invLight + invEye);
    float diffuse  = max(dot(outNormal, invLight), 0.0);
    float specular = pow(clamp(dot(outNormal, halfLE), 0.0, 1.0), 50.0);
    outFragmentColor = outColor * vec4(vec3(diffuse), 1.0);  // diffuse
    outFragmentColor = outFragmentColor + vec4(vec3(specular), 1.0);  // specular
    outFragmentColor = outFragmentColor + ambientColor;  // ambient
}
""".strip()

program = None
vao = None
num_vertex = 0
light_pos_vec = [-3.0, 4.0, 5.0]
eye_pos_vec = [3.0, 4.0, 5.0]
aspect_ratio = 1.0
tb = None

def create_vao(program):
    global num_vertex
    cube_trias, cube_norms = cube_shader.get_cube_triangles()
    num_vertex = cube_trias.size // 3
    position_vbo = gl_util.create_vbo(cube_trias)
    normal_vbo = gl_util.create_vbo(cube_norms)
    
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    
    pos_loc = glGetAttribLocation(program, "position")
    normal_loc = glGetAttribLocation(program, "normal")
    glEnableVertexAttribArray(pos_loc)
    glEnableVertexAttribArray(normal_loc)
    
    glBindBuffer(GL_ARRAY_BUFFER, position_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    
    glBindBuffer(GL_ARRAY_BUFFER, normal_vbo)
    glVertexAttribPointer(normal_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)

    return vao

def init(window, width, height):
    global program, vao, aspect_ratio, tb
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    vao = create_vao(program)
    glUseProgram(program)
    # MVP matrix
    M = glm.mat4(1.0)
    V = glm.lookAt(glm.vec3(3.0, 4.0, 5.0),
        glm.vec3(0.0, 0.0, 0.0),
        glm.vec3(0.0, 1.0, 0.0))
    aspect_ratio = width / height
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, 1.0, 10.0)
    MVP = np.array(P * V * M, dtype=np.float32)
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    glUseProgram(0)
    # トラックボールの初期化
    tb = Trackball()
    tb.region(width, height)

def update(window, width, height):
    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.PRESS and not tb.is_rotating():
        x, y = glfw.get_cursor_pos(window)
        tb.start(x, y)
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.RELEASE:
        tb.stop()
    x, y = glfw.get_cursor_pos(window)
    tb.motion(x, y)

def draw():
    glEnable(GL_DEPTH_TEST)
    glUseProgram(program)
    # MVP matrix
    mdl_rot = tb.get()
    R = glm.mat4(mdl_rot)  # モデルビュー行列に回転を掛け算
    M = R
    V = glm.lookAt(glm.vec3(3.0, 4.0, 5.0),
        glm.vec3(0.0, 0.0, 0.0),
        glm.vec3(0.0, 1.0, 0.0))
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, 1.0, 10.0)
    MVP = np.array(P * V * M, dtype=np.float32)
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    # invM
    invM = glm.inverse(M)
    invM_arr = np.array(invM, dtype=np.float32)
    inv_mat_loc = glGetUniformLocation(program, "invM")
    glUniformMatrix4fv(inv_mat_loc, 1, GL_FALSE, invM_arr)
    # lightPosition
    light_pos_vec_arr = np.array(light_pos_vec, dtype=np.float32)
    light_pos_loc = glGetUniformLocation(program, "lightPosition")
    glUniform3fv(light_pos_loc, 1, light_pos_vec_arr)
    # eyePosition
    eye_pos = np.array(eye_pos_vec, dtype=np.float32)
    eye_pos_loc = glGetUniformLocation(program, "eyePosition")
    glUniform3fv(eye_pos_loc, 1, eye_pos)
    # draw
    glBindVertexArray(vao)
    glDrawArrays(GL_TRIANGLES, 0, num_vertex)
    glBindVertexArray(0)
    glUseProgram(0)
    glDisable(GL_DEPTH_TEST)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
