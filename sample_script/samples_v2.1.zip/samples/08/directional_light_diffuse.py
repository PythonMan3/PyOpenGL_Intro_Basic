from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import my_glm as glm
import cube_shader
import gl_util

vertex_shader_src="""
#version 400 core

in vec3 position;
in vec3 normal;
out vec4 outColor;
uniform mat4 MVP;
uniform vec3 lightDirection;

void main(void) {
    vec4 color = vec4(1.0, 0.0, 0.0, 1.0);
    float diffuse = max(dot(normal, lightDirection), 0.0);
    outColor = color * vec4(vec3(diffuse), 1.0);  // diffuse
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec4 outColor;
out vec4 outFragmentColor;

void main(void){
    outFragmentColor = outColor;
}
""".strip()

program = None
vao = None
num_vertex = 0
light_dir_vec = [3.0, 4.0, 5.0]

def create_vao(program):
    global num_vertex
    cube_trias, cube_norms = cube_shader.get_cube_triangles()
    num_vertex = cube_trias.size // 3
    position_vbo = gl_util.create_vbo(cube_trias)
    normal_vbo = gl_util.create_vbo(cube_norms)
    
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    
    pos_loc = glGetAttribLocation(program, "position")
    normal_loc = glGetAttribLocation(program, "normal")
    glEnableVertexAttribArray(pos_loc)
    glEnableVertexAttribArray(normal_loc)
    
    glBindBuffer(GL_ARRAY_BUFFER, position_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    
    glBindBuffer(GL_ARRAY_BUFFER, normal_vbo)
    glVertexAttribPointer(normal_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)

    return vao

def init(window, width, height):
    global program, vao
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    vao = create_vao(program)
    glUseProgram(program)
    # lightDirection
    light_dir_vec_norm = glm.normalize(glm.vec3(light_dir_vec))
    light_dir = np.array(light_dir_vec_norm, dtype=np.float32)
    light_dir_loc = glGetUniformLocation(program, "lightDirection")
    glUniform3fv(light_dir_loc, 1, light_dir)
    # MVP matrix
    M = glm.mat4(1.0)
    V = glm.lookAt(glm.vec3(3.0, 4.0, 5.0),
        glm.vec3(0.0, 0.0, 0.0),
        glm.vec3(0.0, 1.0, 0.0))
    aspect_ratio = width / height
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, 1.0, 10.0)
    MVP = np.array(P * V * M, dtype=np.float32)
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    glUseProgram(0)

def update(window, width, height):
    pass

def draw():
    glEnable(GL_DEPTH_TEST)
    glUseProgram(program)
    glBindVertexArray(vao)
    glDrawArrays(GL_TRIANGLES, 0, num_vertex)
    glBindVertexArray(0)
    glUseProgram(0)
    glDisable(GL_DEPTH_TEST)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
