from OpenGL.GL import *
import glfw
import numpy as np
import my_glm as glm
import gl_util
from trackball import Trackball

point_vertex_shader_src="""
#version 400 core

in vec3 point_pos;
uniform mat4 mvpMatrix;
uniform float pointSize;

void main(void){
    gl_Position = mvpMatrix * vec4(point_pos, 1.0);
    gl_PointSize = pointSize;
}
""".strip()

point_fragment_shader_src="""
#version 400 core

uniform sampler2D texture0;
uniform int useTexture;
out vec4 fragColor;

void main(void) {
    vec4 smpColor = vec4(1.0);
    if (bool(useTexture)) {
        smpColor = texture(texture0, gl_PointCoord);
    }
    fragColor = smpColor;
}
""".strip()

vertex_shader_src="""
#version 400 core

in vec3 position;
in vec2 textureCoord;
uniform   mat4 mvpMatrix;
out vec2 vTextureCoord;

void main(void) {
    vTextureCoord = textureCoord;
     gl_Position = mvpMatrix * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

uniform sampler2D texture0;
in vec2 vTextureCoord;
out vec4 fragColor;

void main(void){
    fragColor = texture(texture0, vTextureCoord);
}
""".strip()

point_pos = [0.0, 1.0, 0.0]
position = [[-1.0,  1.0,  0.0], [1.0,  1.0,  0.0], [-1.0, -1.0,  0.0], [1.0, -1.0,  0.0]]
textureCoord = [[0.0, 0.0], [1.0, 0.0], [0.0, 1.0], [1.0, 1.0]]
index = [[0, 1, 2], [3, 2, 1]]
program = None
point_program = None
vao = None
point_vao = None
tb = None
mvp_loc = -1
tex_loc = -1
point_mvp_loc = -1
point_tex_loc = -1
point_size_loc = -1
pointSize = 64.0
P = None
V = None
key_released = True
use_texture = True
png_file0 = "hebi.png"
png_file1 = "floor.png"

def create_vao(program):
    position_arr = np.array(position, dtype=np.float32)
    textureCoord_arr = np.array(textureCoord, dtype=np.float32)
    index_arr = np.array(index, dtype=np.int32)

    position_vbo = gl_util.create_vbo(position_arr)
    tex_coord_vbo = gl_util.create_vbo(textureCoord_arr)

    # VAOを作成してバインド
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)

    # アトリビュート変数を有効化
    pos_loc = glGetAttribLocation(program, "position")
    tex_coord_loc = glGetAttribLocation(program, "textureCoord")
    glEnableVertexAttribArray(pos_loc)
    glEnableVertexAttribArray(tex_coord_loc)

    # 座標バッファオブジェクトの位置を指定
    glBindBuffer(GL_ARRAY_BUFFER, position_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)

    # テクスチャ座標を指定
    glBindBuffer(GL_ARRAY_BUFFER, tex_coord_vbo)
    glVertexAttribPointer(tex_coord_loc, 2, GL_FLOAT, GL_FALSE, 0, None)

    # インデックスオブジェクトを作成してデータをGPU側に送る
    index_vbo = glGenBuffers(1)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_vbo)
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_arr, GL_STATIC_DRAW)

    # バッファオブジェクトとVAOをアンバインド
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)

    return vao

def create_point_vao(point_program):
    point_pos_arr = np.array(point_pos, dtype=np.float32)
    point_pos_vbo = gl_util.create_vbo(point_pos_arr)

    # VAOを作成してバインド
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)

    # アトリビュート変数を有効化
    point_pos_loc = glGetAttribLocation(point_program, "point_pos")
    glEnableVertexAttribArray(point_pos_loc)

    # 座標バッファオブジェクトの位置を指定
    glBindBuffer(GL_ARRAY_BUFFER, point_pos_vbo)
    glVertexAttribPointer(point_pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)

    # バッファオブジェクトとVAOをアンバインド
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)

    return vao

def init(window, width, height):
    global program, point_program, vao, point_vao, texture0, texture1, tb
    global mvp_loc, tex_loc, point_mvp_loc, point_size_loc, point_tex_loc, P, V
    glEnable(GL_DEPTH_TEST)
    glDepthFunc(GL_LEQUAL)
    glEnable(GL_BLEND)
    glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE)
    texture0 = gl_util.create_texture(png_file0)
    texture1 = gl_util.create_texture(png_file1)
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    point_program = gl_util.create_program(point_vertex_shader_src, point_fragment_shader_src)
    vao = create_vao(program)
    point_vao = create_point_vao(point_program)
    mvp_loc = glGetUniformLocation(program, 'mvpMatrix')
    tex_loc = glGetUniformLocation(program, 'texture0')
    point_mvp_loc = glGetUniformLocation(point_program, 'mvpMatrix')
    point_tex_loc = glGetUniformLocation(point_program, 'texture0')
    point_size_loc = glGetUniformLocation(point_program, "pointSize")
    # カメラの座標位置
    camera_pos = [0.0, 5.0, 10.0]
    # ビュー座標変換行列
    V = glm.lookAt(glm.vec3(camera_pos), glm.vec3(0.0, 0.0, 0.0), glm.vec3(0.0, 1.0, 0.0))
    # プロジェクション座標変換行列
    P = glm.perspective(45.0, width / height, 0.1, 100.0)
    # トラックボールの初期化
    tb = Trackball()
    tb.region(SCREEN_WIDTH, SCREEN_HEIGHT)

def update(window, width, height):
    global use_texture, key_released
    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.PRESS and not tb.is_rotating():
        x, y = glfw.get_cursor_pos(window)
        tb.start(x, y)
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.RELEASE:
        tb.stop()
    x, y = glfw.get_cursor_pos(window)
    tb.motion(x, y)
    # use_textureを変更
    if glfw.get_key(window, glfw.KEY_SPACE) == glfw.PRESS:
        if key_released:
            use_texture = not use_texture
            key_released = False
    elif glfw.get_key(window, glfw.KEY_SPACE) == glfw.RELEASE:
        key_released = True

def draw():
    glUseProgram(program)
    glBindVertexArray(vao)
    
    # クォータニオンの回転を取得
    mdl_rot = glm.mat4x4(tb.get())

    # フロア用テクスチャをバインド
    glActiveTexture(GL_TEXTURE1)
    glBindTexture(GL_TEXTURE_2D, texture1)
    glUniform1i(tex_loc, 1)

    # フロアのレンダリング
    M = glm.rotate(glm.mat4(), glm.pi() / 2.0, glm.vec3(1.0, 0.0, 0.0))
    M = M * glm.scale(glm.mat4(), glm.vec3(4.0, 4.0, 1.0))
    mvpMatrix = P * V * mdl_rot * M
    mvpMatrix = np.array(mvpMatrix)
    glUniformMatrix4fv(mvp_loc, 1, False, mvpMatrix)
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, None)

    glBindVertexArray(0)
    glUseProgram(0)

    glUseProgram(point_program)
    glBindVertexArray(point_vao)

    glEnable(GL_POINT_SPRITE)               # ポイントスプライトを有効にする
    glEnable(GL_VERTEX_PROGRAM_POINT_SIZE)  # ポイントサイズを有効にする

    # ポイントスプライト用テクスチャをバインド
    glActiveTexture(GL_TEXTURE0)
    glBindTexture(GL_TEXTURE_2D, texture0)
    glUniform1i(point_tex_loc, 0)

    use_tex_loc = glGetUniformLocation(point_program, 'useTexture')
    glUniform1i(use_tex_loc, int(use_texture))

    # ポイントスプライトのレンダリング
    glUniform1f(point_size_loc, pointSize)
    mvpMatrix = P * V
    mvpMatrix = np.array(mvpMatrix)
    glUniformMatrix4fv(point_mvp_loc, 1, False, mvpMatrix)
    glDrawArrays(GL_POINTS, 0, 1)
    glBindVertexArray(0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
