from OpenGL.GL import *
import glfw
import numpy as np
import my_glm as glm
import gl_util
from trackball import Trackball

vertex_shader_src="""
#version 400 core

in vec3 position;
in vec2 textureCoord;
uniform   mat4 mvpMatrix;
out vec2 outTextureCoord;

void main(void) {
    outTextureCoord = textureCoord;
     gl_Position = mvpMatrix * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

uniform sampler2D texture0;
in vec2 outTextureCoord;
out vec4 fragColor;

void main(void) {
    fragColor = texture(texture0, outTextureCoord);
}
""".strip()

position = [[-1.0,  1.0,  0.0], [1.0,  1.0,  0.0], [-1.0, -1.0,  0.0], [1.0, -1.0,  0.0]]
textureCoord = [[0.0, 0.0], [1.0, 0.0], [0.0, 1.0], [1.0, 1.0]]
index = [[0, 1, 2], [3, 2, 1]]
program = None
vao = None
tb = None
mvp_loc = -1
tex_loc = -1
P = None
V = None
revV = None
key_released = True
is_billboard = True
png_file0 = "hebi.png"
png_file1 = "floor.png"

def create_vao(program):
    position_arr = np.array(position, dtype=np.float32)
    textureCoord_arr = np.array(textureCoord, dtype=np.float32)
    index_arr = np.array(index, dtype=np.int32)

    position_vbo = gl_util.create_vbo(position_arr)
    tex_coord_vbo = gl_util.create_vbo(textureCoord_arr)

    # VAOを作成してバインド
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)

    # アトリビュート変数を有効化
    pos_loc = glGetAttribLocation(program, "position")
    tex_coord_loc = glGetAttribLocation(program, "textureCoord")
    glEnableVertexAttribArray(pos_loc)
    glEnableVertexAttribArray(tex_coord_loc)

    # 座標バッファオブジェクトの位置を指定
    glBindBuffer(GL_ARRAY_BUFFER, position_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)

    # テクスチャ座標を指定
    glBindBuffer(GL_ARRAY_BUFFER, tex_coord_vbo)
    glVertexAttribPointer(tex_coord_loc, 2, GL_FLOAT, GL_FALSE, 0, None)

    # インデックスオブジェクトを作成してデータをGPU側に送る
    index_vbo = glGenBuffers(1)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, index_vbo)
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_arr, GL_STATIC_DRAW)

    # バッファオブジェクトとVAOをアンバインド
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)

    return vao

def init(window, width, height):
    global program, vao, texture0, texture1, tb
    global mvp_loc, tex_loc, P, V, revV
    glEnable(GL_DEPTH_TEST)
    glDepthFunc(GL_LEQUAL)
    glEnable(GL_BLEND)
    glBlendFuncSeparate(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA, GL_ONE, GL_ONE)
    texture0 = gl_util.create_texture(png_file0)
    texture1 = gl_util.create_texture(png_file1)
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    vao = create_vao(program)
    mvp_loc = glGetUniformLocation(program, 'mvpMatrix')
    tex_loc = glGetUniformLocation(program, 'texture0')
    # カメラの座標位置
    camera_pos = [0.0, 5.0, 10.0]
    # ビュー座標変換行列
    V = glm.lookAt(glm.vec3(camera_pos), glm.vec3(0.0, 0.0, 0.0), glm.vec3(0.0, 1.0, 0.0))
    # ビルボード用のビュー座標変換行列
    revV = glm.lookAt(glm.vec3(0.0, 0.0, 0.0), glm.vec3(camera_pos), glm.vec3(0.0, 1.0, 0.0))
    # プロジェクション座標変換行列
    P = glm.perspective(45.0, width / height, 0.1, 100.0)
    # トラックボールの初期化
    tb = Trackball()
    tb.region(SCREEN_WIDTH, SCREEN_HEIGHT)

def update(window, width, height):
    global is_billboard, key_released
    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.PRESS and not tb.is_rotating():
        x, y = glfw.get_cursor_pos(window)
        tb.start(x, y)
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.RELEASE:
        tb.stop()
    x, y = glfw.get_cursor_pos(window)
    tb.motion(x, y)
    # is_billboardを変更
    if glfw.get_key(window, glfw.KEY_SPACE) == glfw.PRESS:
        if key_released:
            is_billboard = not is_billboard
            key_released = False
    elif glfw.get_key(window, glfw.KEY_SPACE) == glfw.RELEASE:
        key_released = True

def draw():
    glUseProgram(program)
    glBindVertexArray(vao)
    
    # クォータニオンの回転を取得
    mdl_rot = glm.mat4x4(tb.get())

    # フロア用テクスチャをバインド
    glActiveTexture(GL_TEXTURE1)
    glBindTexture(GL_TEXTURE_2D, texture1)
    glUniform1i(tex_loc, 1)

    # フロアのレンダリング
    M = glm.rotate(glm.mat4(), glm.pi() / 2.0, glm.vec3(1.0, 0.0, 0.0))
    M = M * glm.scale(glm.mat4(), glm.vec3(4.0, 4.0, 1.0))
    mvpMatrix = P * V * mdl_rot * M
    mvpMatrix = np.array(mvpMatrix)
    glUniformMatrix4fv(mvp_loc, 1, False, mvpMatrix)
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, None)

    # ビルボード用テクスチャをバインド
    glActiveTexture(GL_TEXTURE0)
    glBindTexture(GL_TEXTURE_2D, texture0)
    glUniform1i(tex_loc, 0)

    # ビルボードのレンダリング
    M = glm.translate(glm.mat4(), glm.vec3(0.0, 1.0, 0.0))
    if is_billboard:
        M = M * glm.rotate(glm.mat4(), glm.pi(), glm.vec3(0.0, 1.0, 0.0))  # 左右を反転
        invV = glm.inverse(revV)  # 視点と注目点を入れ替えたビュー行列を逆行列にする
        mvpMatrix = P * V * invV * M
    else:
        mvpMatrix = P * V * mdl_rot * M
    mvpMatrix = np.array(mvpMatrix)
    glUniformMatrix4fv(mvp_loc, 1, False, mvpMatrix)
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, None)

    glBindVertexArray(0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
