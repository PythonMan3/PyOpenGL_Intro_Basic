from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import gl_util

vert_pos = [
    [-0.5, -0.5, 0.0],  # 頂点 0
    [0.5, -0.5, 0.0],   # 頂点 1
    [0.5, 0.5, 0.0],    # 頂点 2
    [-0.5, 0.5, 0.0]]   # 頂点 3
vert_color = [
    [1.0, 0.0, 0.0],    # 頂点 0
    [0.0, 1.0, 0.0],    # 頂点 1
    [0.0, 0.0, 1.0],    # 頂点 2
    [0.8, 0.8, 0.8]]    # 頂点 3
tria_index = [[0, 1, 2], [2, 3, 0]]
num_vertex = 0
program = None
vao = None
pos_loc = -1
color_loc = -1

vertex_shader_src="""
#version 400 core

in vec3 position;
in vec3 color;
out vec3 outColor;

void main(void) {
    outColor = color;
    gl_Position = vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec3 outColor;
out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = vec4(outColor, 1.0);
}
""".strip()

def create_vao(vert_pos, vert_color):
    pos_vbo = gl_util.create_vbo(vert_pos)
    color_vbo = gl_util.create_vbo(vert_color)
    # VAO を作成
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    glEnableVertexAttribArray(pos_loc)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    glEnableVertexAttribArray(color_loc)
    glBindBuffer(GL_ARRAY_BUFFER, color_vbo)
    glVertexAttribPointer(color_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)
    return vao

def init(window, width, height):
    global program, vao, pos_loc, color_loc, num_vertex, vert_pos, vert_color, tria_index
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_loc = glGetAttribLocation(program, "position")
    color_loc = glGetAttribLocation(program, "color")
    vert_pos = np.array(vert_pos, dtype=np.float32)
    vert_color = np.array(vert_color, dtype=np.float32)
    tria_index = np.array(tria_index, dtype=np.uint32)
    num_vertex = tria_index.size
    vao = create_vao(vert_pos, vert_color)

def update(window, width, height):
    pass

def draw():
    glUseProgram(program)
    glBindVertexArray(vao)
    glDrawElements(GL_TRIANGLES, num_vertex, GL_UNSIGNED_INT, tria_index)
    glBindVertexArray(0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
