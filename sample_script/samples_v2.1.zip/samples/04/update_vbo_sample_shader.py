from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import gl_util
import numpy as np
import copy

vert_pos = [[0.0, 0.5, 0.0], [-0.5, -0.5, 0.0], [0.5, -0.5, 0.0]]
dists = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.4, 0.3, 0.2, 0.1]
vbo = None
vao = None
num_vertex = 0
program = None
pos_loc = -1

vertex_shader_src="""
#version 400 core

in vec3 position;

void main(void) {
    gl_Position = vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = vec4(1.0);
}
""".strip()

def create_vao(pos_vbo):
    # VAO を作成
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    glEnableVertexAttribArray(pos_loc)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)
    return vao

def init(window, width, height):
    global vbo, vao, pos_loc, num_vertex, program
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_loc = glGetAttribLocation(program, "position")
    pos = np.array(vert_pos, dtype=np.float32)
    num_vertex = pos.size
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, pos.nbytes, None, GL_DYNAMIC_DRAW)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    vao = create_vao(vbo)

def update(window, width, height):
    elapsed_seconds = glfw.get_time()
    dist = dists[int(elapsed_seconds / 0.5) % 10]
    new_vert_pos = copy.deepcopy(vert_pos)
    new_vert_pos[0][1] += dist
    new_vert_pos[1][0] -= dist
    new_vert_pos[2][0] += dist
    pos = np.array(new_vert_pos, dtype=np.float32)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferSubData(GL_ARRAY_BUFFER, 0, pos.nbytes, pos)
    glBindBuffer(GL_ARRAY_BUFFER, 0)

def draw():
    glUseProgram(program)
    glBindVertexArray(vao)
    glDrawArrays(GL_TRIANGLES, 0, num_vertex)
    glBindVertexArray(0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
