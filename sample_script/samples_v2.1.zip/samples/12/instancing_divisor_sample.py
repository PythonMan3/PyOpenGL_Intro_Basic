from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import gl_util

vert_pos = np.array([[0.0, 0.2, 0.0], [-0.2, -0.2, 0.0], [0.2, -0.2, 0.0]], dtype=np.float32)
# instance
color_div = 1
vert_color = np.array([
    [1.0, 0.0, 0.0, 1.0],    # 赤
    [0.0, 1.0, 0.0, 1.0],    # 緑
    [0.0, 0.0, 1.0, 1.0],    # 青
    [1.0, 1.0, 0.0, 1.0],    # 黄
    [0.0, 1.0, 1.0, 1.0],    # シアン
    [1.0, 0.0, 1.0, 1.0],    # ピンク
    [1.0, 1.0, 1.0, 1.0],    # 白
    [0.5, 0.5, 0.5, 1.0],    # グレー
    [0.25, 0.25, 0.25, 1.0]  # 濃いグレー
    ], dtype=np.float32)

offset_array = []
offset = 0.5
for y in range(0, 3):
    for x in range(0, 3):
        trans = [-0.5, -0.5, 0.0]
        trans[0] += offset * x
        trans[1] += offset * y
        offset_array.append(trans)
len_of_offset_array = len(offset_array)
offset_array = np.array(offset_array, dtype=np.float32)

program = None
pos_vbo = None
color_vbo = None
offset_vbo = None
pos_loc = -1
color_loc = -1
offset_loc = -1

vertex_shader_src="""
#version 400 core

in vec3 position;
in vec3 color;
in vec3 offset;
out vec3 outColor;

void main(void) {
    outColor = color;
    gl_Position = vec4(position + offset, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec3 outColor;
out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = vec4(outColor, 1.0);
}
""".strip()

def init(window, width, height):
    global program, pos_vbo, color_vbo, offset_vbo, pos_loc, color_loc, offset_loc
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_loc = glGetAttribLocation(program, "position")
    color_loc = glGetAttribLocation(program, "color")
    offset_loc = glGetAttribLocation(program, "offset")
    pos_vbo = gl_util.create_vbo(vert_pos)
    color_vbo = gl_util.create_vbo(vert_color)
    offset_vbo = gl_util.create_vbo(offset_array)

def update(window, width, height):
    pass

def draw():
    glUseProgram(program)
    glEnableVertexAttribArray(pos_loc)
    glEnableVertexAttribArray(color_loc)
    glEnableVertexAttribArray(offset_loc)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, color_vbo)
    glVertexAttribPointer(color_loc, 4, GL_FLOAT, GL_FALSE, 0, None)
    glVertexAttribDivisor(color_loc, color_div)
    glBindBuffer(GL_ARRAY_BUFFER, offset_vbo)
    glVertexAttribPointer(offset_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    glVertexAttribDivisor(offset_loc, 1)
    num_vertex = vert_pos.size // 3
    glDrawArraysInstanced(GL_TRIANGLES, 0, num_vertex, len_of_offset_array)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
