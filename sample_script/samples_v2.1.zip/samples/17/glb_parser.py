import struct
import json
import numpy as np
from urllib import request

class Reader:
    def __init__(self, data: bytes)->None:
        self.data = data
        self.pos = 0

    def read_str(self, size):
        result = self.data[self.pos: self.pos + size]
        self.pos += size
        return result.strip()

    def read(self, size):
        result = self.data[self.pos: self.pos + size]
        self.pos += size
        return result

    def read_uint(self):
        result = struct.unpack('I', self.data[self.pos:self.pos + 4])[0]
        self.pos += 4
        return result

def parse_glb(data: bytes):
    reader = Reader(data)
    magic = reader.read_str(4)
    if  magic != b'glTF':
        raise Exception(f'magic not found: #{magic}')

    version = reader.read_uint()
    if version != 2:
        raise Exception(f'version:#{version} is not 2')

    size = reader.read_uint()
    size -= 12

    json_str = None
    body = None
    while size > 0:
        #print(size)

        chunk_size = reader.read_uint()
        size -= 4

        chunk_type = reader.read_str(4)
        size -= 4

        chunk_data = reader.read(chunk_size)
        size -= chunk_size

        if chunk_type == b'BIN\x00':
            body = chunk_data
        elif chunk_type == b'JSON':
            json_str = chunk_data
        else:
            raise Exception(f'unknown chunk_type: {chunk_type}')

    return json.loads(json_str), body

def get_variable_np_type(comp_type):
    comp_d = {
        5120: np.int8,
        5121: np.uint8,
        5122: np.int16,
        5123: np.uint16,
        5125: np.uint32,
        5126: np.float32}
    if comp_type in comp_d:
        return comp_d[comp_type]
    else:
        raise ValueError("Not supported component type.")

def get_element_count_by_type_name(accessor_type):
    return {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}[accessor_type]

def get_buffer_data(gltf, body, accessor_idx, to_binary=True):
    buffer_view_idx = gltf['accessors'][accessor_idx]['bufferView']
    accessor_byte_offset     = 0
    if 'byteOffset' in gltf['accessors'][accessor_idx]:
        accessor_byte_offset = gltf['accessors'][accessor_idx]['byteOffset']
    comp_type                = gltf['accessors'][accessor_idx]['componentType']
    accessor_count           = gltf['accessors'][accessor_idx]['count']
    accessor_type            = gltf['accessors'][accessor_idx]['type']
    max_data, min_data = None, None
    if 'max' in gltf['accessors'][accessor_idx]:
        max_data             = gltf['accessors'][accessor_idx]['max']
    if 'min' in gltf['accessors'][accessor_idx]:
        min_data             = gltf['accessors'][accessor_idx]['min']
    accessor_element_count   = get_element_count_by_type_name(accessor_type)
    buffer_view_buffer       = gltf['bufferViews'][buffer_view_idx]['buffer']
    buffer_view_byte_offset  = gltf['bufferViews'][buffer_view_idx]['byteOffset']
    buffer_view_byte_length  = gltf['bufferViews'][buffer_view_idx]['byteLength']
    stride = 0
    if 'byteStride' in gltf['bufferViews'][buffer_view_idx]:
        stride  = gltf['bufferViews'][buffer_view_idx]['byteStride']
    data_uri = None
    if 'uri' in gltf['buffers'][buffer_view_buffer]:
        data_uri             = gltf['buffers'][buffer_view_buffer]['uri']
    # バッファデータを取得
    if to_binary:
        data_bytes = body[buffer_view_byte_offset:buffer_view_byte_offset+buffer_view_byte_length]
        return data_bytes, buffer_view_byte_length, accessor_count, accessor_element_count, comp_type, max_data, min_data, stride, accessor_byte_offset
    else:
        np_type = get_variable_np_type(comp_type)
        data_arr = np.frombuffer(body, dtype=np_type, count=accessor_element_count * accessor_count, offset=buffer_view_byte_offset)
        return data_arr, 0, accessor_count, accessor_element_count, comp_type, max_data, min_data, stride, accessor_byte_offset

if __name__ == "__main__":
    with open('data/simple_binary.glb', 'rb') as fi:
        parsed, body = parse_glb(fi.read())
        json_formatted_str = json.dumps(parsed, indent=4)
        print(json_formatted_str)
        