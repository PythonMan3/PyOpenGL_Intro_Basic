import json
import numpy as np
from urllib import request

def get_element_count_by_type_name(accessor_type):
    return {"SCALAR": 1, "VEC3": 3}[accessor_type]

def get_variable_np_type(comp_type):
    return {5123: np.uint16, 5126: np.float32}[comp_type]

with open('data/simple.gltf', 'rb') as fi:
    # JSONをパース
    json_str = fi.read()
    gltf = json.loads(json_str)
    
    # インデックスデータをパース
    #  "meshes" : [
    #    {
    #      "primitives" : [ {
    #        "attributes" : {
    #          "POSITION" : 1
    #        },
    #        "indices" : 0
    #      } ]
    #    }
    #  ],
    accessor_idx            = gltf['meshes'][0]['primitives'][0]['indices']  # 0
    # "accessors" : [
    #   {
    #     "bufferView" : 0,
    #     "byteOffset" : 0,
    #     "componentType" : 5123,
    #     "count" : 3,
    #     "type" : "SCALAR",
    #     "max" : [ 2 ],
    #     "min" : [ 0 ]
    #   },
    buffer_view_idx         = gltf['accessors'][accessor_idx]['bufferView']     # 0
    accessor_byte_offset    = gltf['accessors'][accessor_idx]['byteOffset']     # 0
    comp_type               = gltf['accessors'][accessor_idx]['componentType']  # 5123
    accessor_count          = gltf['accessors'][accessor_idx]['count']          # 3
    accessor_type           = gltf['accessors'][accessor_idx]['type']           # "SCALAR"
    accessor_element_count  = get_element_count_by_type_name(accessor_type)     # 1
    np_type                 = get_variable_np_type(comp_type)                   # np.uint16
    # "bufferViews" : [
    #   {
    #     "buffer" : 0,
    #     "byteOffset" : 0,
    #     "byteLength" : 6,
    #     "target" : 34963
    #   },
    buffer_view_buffer      = gltf['bufferViews'][buffer_view_idx]['buffer']      # 0
    buffer_view_byte_offset = gltf['bufferViews'][buffer_view_idx]['byteOffset']  # 0
    buffer_view_byte_length = gltf['bufferViews'][buffer_view_idx]['byteLength']  # 6
    buffer_view_byte_offset += accessor_byte_offset
    # "buffers" : [
    #   {
    #     "uri" : "data:application/octet-stream;base64,AAABAAIAAAAAAAAAAAAAAAAAAAAAAIA/AAAAAAAAAAAAAAAAAACAPwAAAAA=",
    #     "byteLength" : 44
    #   }
    # ],
    data_uri                = gltf['buffers'][buffer_view_buffer]['uri']  # data:application/octet-stream;base64,AAA...
    # インデックスデータを取得
    with request.urlopen(data_uri) as response:
        data_bytes = response.read()
        ind_arr = np.frombuffer(data_bytes, dtype=np_type,
            count=accessor_element_count * accessor_count, offset=buffer_view_byte_offset)
        print("index={}".format(ind_arr))  # index=[0 1 2]
    
    # 頂点位置データをパース
    #  "meshes" : [
    #    {
    #      "primitives" : [ {
    #        "attributes" : {
    #          "POSITION" : 1
    #        },
    #        "indices" : 0
    #      } ]
    #    }
    #  ],
    accessor_idx            = gltf['meshes'][0]['primitives'][0]['attributes']['POSITION']  # 1
    # "accessors" : [
    #   ...
    #   {
    #     "bufferView" : 1,
    #     "byteOffset" : 0,
    #     "componentType" : 5126,
    #     "count" : 3,
    #     "type" : "VEC3",
    #     "max" : [ 1.0, 1.0, 0.0 ],
    #     "min" : [ 0.0, 0.0, 0.0 ]
    #   }
    buffer_view_idx         = gltf['accessors'][accessor_idx]['bufferView']     # 1
    accessor_byte_offset    = gltf['accessors'][accessor_idx]['byteOffset']     # 0
    comp_type               = gltf['accessors'][accessor_idx]['componentType']  # 5126
    accessor_count          = gltf['accessors'][accessor_idx]['count']          # 3
    accessor_type           = gltf['accessors'][accessor_idx]['type']           # "VEC3"
    accessor_element_count  = get_element_count_by_type_name(accessor_type)     # 3
    np_type                 = get_variable_np_type(comp_type)                   # np.float32
    # "bufferViews" : [
    #   ...
    #   {
    #     "buffer" : 0,
    #     "byteOffset" : 8,
    #     "byteLength" : 36,
    #     "target" : 34962
    #   }
    buffer_view_buffer      = gltf['bufferViews'][buffer_view_idx]['buffer']      # 0
    buffer_view_byte_offset = gltf['bufferViews'][buffer_view_idx]['byteOffset']  # 8
    buffer_view_byte_length = gltf['bufferViews'][buffer_view_idx]['byteLength']  # 36
    buffer_view_byte_offset += accessor_byte_offset
    # "buffers" : [
    #   {
    #     "uri" : "data:application/octet-stream;base64,AAABAAIAAAAAAAAAAAAAAAAAAAAAAIA/AAAAAAAAAAAAAAAAAACAPwAAAAA=",
    #     "byteLength" : 44
    #   }
    # ],
    data_uri                = gltf['buffers'][buffer_view_buffer]['uri']  # data:application/octet-stream;base64,AAA...
    # 頂点位置データを取得
    pos_arr = None
    with request.urlopen(data_uri) as response:
        data_bytes = response.read()
        pos_arr = np.frombuffer(data_bytes, dtype=np_type,
            count=accessor_element_count * accessor_count, offset=buffer_view_byte_offset)
        print("position={}".format(pos_arr))  # position=[0. 0. 0. 1. 0. 0. 0. 1. 0.]
