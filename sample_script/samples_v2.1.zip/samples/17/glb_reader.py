from OpenGL.GL import *
from OpenGL.GLU import *
import gl_util
import my_glm as glm
import numpy as np
from bounding_box import BoundBox
import glb_parser
from ctypes import c_void_p

def get_variable_type(comp_type):
    comp_d = {
        5120: GL_BYTE,
        5121: GL_UNSIGNED_BYTE,
        5122: GL_SHORT,
        5123: GL_UNSIGNED_SHORT,
        5125: GL_UNSIGNED_INT,
        5126: GL_FLOAT}
    if comp_type in comp_d:
        return comp_d[comp_type]
    else:
        raise ValueError("Not supported component type.")

class GlbReader:
    def __init__(self, model_file):
        self.model = Model()
        self.model.import_file(model_file)
        
    def read_mesh(self):
        self.model.read_mesh()
        self.model.read_tree_node()
        self.model.read_bone()
        self.model.read_animation()
        self.model.calc_node_transform()  # nodeの位置をメッシュに反映させるため
        self.create_vao()
        
    def create_vao(self):
        for mat in self.model.materials:
            mat.vao = glGenVertexArrays(1)
            glBindVertexArray(mat.vao)
            glEnableVertexAttribArray(0)
            glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_vertex)
            glVertexAttribPointer(0, mat.pos_elem_count, mat.pos_type, GL_FALSE, mat.pos_stride, c_void_p(mat.pos_offset))
            if mat.has_normal:
                glEnableVertexAttribArray(1)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_normal)
                glVertexAttribPointer(1, mat.norm_elem_count, GL_FLOAT, GL_FALSE, mat.norm_stride, c_void_p(mat.norm_offset))
            if mat.has_uv:
                glEnableVertexAttribArray(2)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_tex_coord)
                glVertexAttribPointer(2, mat.uv_elem_count, GL_FLOAT, GL_FALSE, mat.uv_stride, c_void_p(mat.uv_offset))
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mat.ibo_faces)
            if mat.vbo_bone_id:
                glEnableVertexAttribArray(3)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_bone_id)
                glVertexAttribIPointer(3, 4, mat.bone_id_type, mat.bone_stride, c_void_p(mat.bone_offset))
            if mat.vbo_bone_weight:
                glEnableVertexAttribArray(4)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_bone_weight)
                glVertexAttribPointer(4, 4, mat.weight_type, GL_FALSE, mat.weight_stride, c_void_p(mat.weight_offset))
            glBindBuffer(GL_ARRAY_BUFFER, 0)
            glBindVertexArray(0)
    
class Model:
    def __init__(self):
        self.bound_box = BoundBox()
        self.model_file = ""
        self.materials = []
        self.nodes = []
        self.animations = []
        self.parsed = ""
        self.body = None
        self.vbo_ids = []  # 作成済みのVBOのリスト(重複して作成するのを避けるため)
        self.mesh_mat_d = {}
        self.root_nodes = []
        
    def import_file(self, file_name):
        with open(file_name, 'rb') as fi:
            self.parsed, self.body = glb_parser.parse_glb(fi.read())
            if 'accessors' in self.parsed:
                self.vbo_ids = [None] * len(self.parsed['accessors'])
        self.model_file = file_name
    
    def read_mesh(self):
        mesh_idxs = []
        node_list = self.parsed['nodes']
        for node in node_list:
            if 'mesh' in node:
                mesh_idx = node['mesh']
                mesh_idxs.append(mesh_idx)
        for mesh_idx in mesh_idxs:
            prim_list = self.parsed['meshes'][mesh_idx]['primitives']
            num_prim = len(prim_list)
            for prim_idx in range(num_prim):
                mat = Material()
                if mesh_idx in self.mesh_mat_d:  # mesh内にprimitiveが複数ある場合がある
                    self.mesh_mat_d[mesh_idx].append(mat)
                else:
                    self.mesh_mat_d[mesh_idx] = [mat]
                self.materials.append(mat)
                # position
                pos_acce_idx = self.parsed['meshes'][mesh_idx]['primitives'][prim_idx]['attributes']['POSITION']
                if not self.vbo_ids[pos_acce_idx]:
                    data_buffer, byte_len, count, elem_cnt, comp_type, max_pos, min_pos, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, pos_acce_idx)
                    mat.max_pos = max_pos
                    mat.min_pos = min_pos
                    mat.pos_elem_count = elem_cnt
                    mat.pos_type = get_variable_type(comp_type)
                    mat.pos_stride = stride
                    mat.pos_offset = offset
                    mat.vbo_vertex = gl_util.create_vbo(data_buffer, byte_len)
                    self.vbo_ids[pos_acce_idx] = (mat.pos_elem_count, mat.pos_type, mat.vbo_vertex, mat.pos_stride, mat.pos_offset)
                else:
                    pos_elem_count, pos_type, vbo_vertex, stride, offset = self.vbo_ids[pos_acce_idx]
                    mat.pos_elem_count = pos_elem_count
                    mat.pos_type = pos_type
                    mat.pos_stride = stride
                    mat.pos_offset = offset
                    mat.vbo_vertex = vbo_vertex
                # face
                face_acce_idx = self.parsed['meshes'][mesh_idx]['primitives'][prim_idx]['indices']
                if not self.vbo_ids[face_acce_idx]:
                    data_buffer, byte_len, count, elem_cnt, comp_type, max_pos, min_pos, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, face_acce_idx)
                    mat.idx_type = get_variable_type(comp_type)
                    mat.num_face = count // 3
                    mat.ibo_faces = gl_util.create_ibo(data_buffer, byte_len)
                    self.vbo_ids[face_acce_idx] = (mat.idx_type, mat.num_face, mat.ibo_faces)
                else:
                    idx_type, num_face, ibo_faces = self.vbo_ids[face_acce_idx]
                    mat.idx_type = idx_type
                    mat.num_face = num_face
                    mat.ibo_faces = ibo_faces
                # normal
                if 'NORMAL' in self.parsed['meshes'][mesh_idx]['primitives'][prim_idx]['attributes']:
                    norm_acce_idx = self.parsed['meshes'][mesh_idx]['primitives'][prim_idx]['attributes']['NORMAL']
                    if not self.vbo_ids[norm_acce_idx]:
                        data_buffer, byte_len, count, elem_cnt, comp_type, max_pos, min_pos, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, norm_acce_idx)
                        mat.has_normal = True
                        mat.norm_elem_count = elem_cnt
                        mat.norm_stride = stride
                        mat.norm_offset = offset
                        mat.vbo_normal = gl_util.create_vbo(data_buffer, byte_len)
                        self.vbo_ids[norm_acce_idx] = (mat.has_normal, mat.norm_elem_count, mat.vbo_normal, mat.norm_stride, mat.norm_offset)
                    else:
                        has_normal, norm_elem_count, vbo_normal, stride, offset = self.vbo_ids[norm_acce_idx]
                        mat.has_normal = has_normal
                        mat.norm_elem_count = norm_elem_count
                        mat.norm_stride = stride
                        mat.norm_offset = offset
                        mat.vbo_normal = vbo_normal
                # texture coords
                if 'TEXCOORD_0' in self.parsed['meshes'][mesh_idx]['primitives'][prim_idx]['attributes']:
                    tex_acce_idx = self.parsed['meshes'][mesh_idx]['primitives'][prim_idx]['attributes']['TEXCOORD_0']
                    if not self.vbo_ids[tex_acce_idx]:
                        data_buffer, byte_len, count, elem_cnt, comp_type, max_pos, min_pos, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, tex_acce_idx)
                        mat.has_uv = True
                        mat.uv_elem_count = elem_cnt
                        mat.uv_stride = stride
                        mat.uv_offset = offset
                        mat.vbo_tex_coord = gl_util.create_vbo(data_buffer, byte_len)
                        self.vbo_ids[tex_acce_idx] = (mat.has_uv, mat.uv_elem_count, mat.vbo_tex_coord, mat.uv_stride, mat.uv_offset)
                    else:
                        has_uv, uv_elem_count, vbo_tex_coord, stride, offset = self.vbo_ids[tex_acce_idx]
                        mat.has_uv = has_uv
                        mat.uv_elem_count = uv_elem_count
                        mat.uv_stride = stride
                        mat.uv_offset = offset
                        mat.vbo_tex_coord = vbo_tex_coord
                # texture
                if 'material' in self.parsed['meshes'][mesh_idx]['primitives'][prim_idx]:
                    mat_idx = self.parsed['meshes'][mesh_idx]['primitives'][prim_idx]['material']
                    if 'alphaMode' in self.parsed['materials'][mat_idx]:
                        mat.alpha_mode = self.parsed['materials'][mat_idx]['alphaMode']
                    if 'alphaCutoff' in self.parsed['materials'][mat_idx]:
                        mat.alpha_cutoff = self.parsed['materials'][mat_idx]['alphaCutoff']
                    if 'baseColorFactor' in self.parsed['materials'][mat_idx]['pbrMetallicRoughness']:
                        mat.diffuse_color = self.parsed['materials'][mat_idx]['pbrMetallicRoughness']['baseColorFactor']
                    if 'images' in self.parsed:
                        tex_idx = self.parsed['materials'][mat_idx]['pbrMetallicRoughness']['baseColorTexture']['index']
                        img_idx = self.parsed['textures'][tex_idx]['source']
                        idx_buff_view = self.parsed['images'][img_idx]['bufferView']
                        mime_type = self.parsed['images'][img_idx]['mimeType']
                        idx_buff = self.parsed['bufferViews'][idx_buff_view]['buffer']
                        byte_offset = self.parsed['bufferViews'][idx_buff_view]['byteOffset']
                        byte_len = self.parsed['bufferViews'][idx_buff_view]['byteLength']
                        mat.has_texture = True
                        mat.texture = gl_util.create_texture(self.body[byte_offset:byte_offset+byte_len], byte_len)
            
    def set_child_trans(self, node):
        for child_node in node.children:
            child_node.combined_matrix = node.combined_matrix * child_node.transform_matrix
            if child_node.mesh_index in  self.mesh_mat_d:
                mats = self.mesh_mat_d[child_node.mesh_index]
                for mat in mats:
                    mat.transform_matrix = child_node.combined_matrix
                    if mat.max_pos and mat.min_pos:
                        max_pos = list(mat.transform_matrix * glm.vec4(glm.vec3(mat.max_pos), 1.0))[:3]
                        min_pos = list(mat.transform_matrix * glm.vec4(glm.vec3(mat.min_pos), 1.0))[:3]
                        self.bound_box.add_point(max_pos)
                        self.bound_box.add_point(min_pos)
            self.set_child_trans(child_node)
            
    def calc_node_transform(self):
        for root_node in self.root_nodes:
            root_node.combined_matrix = root_node.transform_matrix
            if root_node.mesh_index in  self.mesh_mat_d:
                mats = self.mesh_mat_d[root_node.mesh_index]
                for mat in mats:
                    mat.transform_matrix = root_node.combined_matrix
                    if mat.max_pos and mat.min_pos:
                        max_pos = list(mat.transform_matrix * glm.vec4(glm.vec3(mat.max_pos), 1.0))[:3]
                        min_pos = list(mat.transform_matrix * glm.vec4(glm.vec3(mat.min_pos), 1.0))[:3]
                        self.bound_box.add_point(max_pos)
                        self.bound_box.add_point(min_pos)
            self.set_child_trans(root_node)
            
    def read_tree_node(self):
        if 'scenes' not in self.parsed or len(self.parsed['scenes']) <= 0:
            return
        scene_d = self.parsed['scenes'][0]
        if 'nodes' not in scene_d:
            return
        node_idxs = scene_d['nodes']
        nodes_list = self.parsed['nodes']
        for idx in node_idxs:
            top_node_d = nodes_list[idx]
            name = top_node_d['name']
            if name == 'Light' or name == 'Camera':
                continue
            node_name = name
            node_idx = idx
            root_node = Node(node_name)
            root_node.index = len(self.nodes)
            root_node.node_index = node_idx
            if 'mesh' in top_node_d:
                root_node.mesh_index = top_node_d['mesh']
            trans, rot, scale = [glm.mat4(1.0)] * 3
            if 'translation' in top_node_d:
                pos = top_node_d['translation']
                trans = glm.translate(glm.mat4(1.0), glm.vec3(pos[0], pos[1], pos[2]))
                root_node.translation = pos
            if 'rotation' in top_node_d:
                rot_ = top_node_d['rotation']
                quat = glm.quat(rot_[3], rot_[0], rot_[1], rot_[2])
                rot = glm.mat4_cast(quat)
                root_node.rotation = rot_
            if 'scale' in top_node_d:
                sca = top_node_d['scale']
                scale = glm.scale(glm.mat4(1.0), glm.vec3(sca[0], sca[1], sca[2]))
                root_node.scale = sca
            root_node.transform_matrix = trans * rot * scale
            self.nodes.append(root_node)
            add_node(root_node, self.nodes, top_node_d, nodes_list)
            self.root_nodes.append(root_node)
        
    def read_bone(self):
        mesh_idxs = []
        node_list = self.parsed['nodes']
        for node_d in node_list:
            if 'mesh' in node_d:
                mesh_idx = node_d['mesh']
                skin_idx = -1
                if 'skin' in node_d:
                    skin_idx = node_d['skin']
                mesh_idxs.append([mesh_idx, skin_idx])
        mat_idx = 0
        for mesh_idx, skin_idx in mesh_idxs:
            prim_list = self.parsed['meshes'][mesh_idx]['primitives']
            num_prim = len(prim_list)
            for prim_idx in range(num_prim):
                prim_d = prim_list[prim_idx]
                mat = self.materials[mat_idx]
                mat_idx += 1
                if 'JOINTS_0' in prim_d['attributes']:
                    joint_acce_idx = prim_d['attributes']['JOINTS_0']
                    data_buffer, byte_len, count, elem_cnt, comp_type, max_data, min_data, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, joint_acce_idx)
                    mat.bone_id_type = get_variable_type(comp_type)
                    mat.bone_stride = stride
                    mat.bone_offset = offset
                    mat.vbo_bone_id = gl_util.create_ibo(data_buffer, byte_len)
                if 'WEIGHTS_0' in prim_d['attributes']:
                    weight_acce_idx = prim_d['attributes']['WEIGHTS_0']
                    data_buffer, byte_len, count, elem_cnt, comp_type, max_data, min_data, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, weight_acce_idx)
                    mat.weight_type = get_variable_type(comp_type)
                    mat.weight_stride = stride
                    mat.weight_offset = offset
                    mat.vbo_bone_weight = gl_util.create_vbo(data_buffer, byte_len)
            if 'skins' in self.parsed:
                skin_list = self.parsed['skins']
                skin_d = skin_list[skin_idx]
                offset_mat_acce_idx = skin_d['inverseBindMatrices']
                offset_mat_arr, byte_len, count, elem_cnt, comp_type, max_data, min_data, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, offset_mat_acce_idx, False)
                offset_mat_arr = offset_mat_arr.reshape(count, elem_cnt)
                joint_list = skin_d['joints']
                for joint_idx, node_idx in enumerate(joint_list):
                    node = self.find_node(node_idx)
                    mat.node_indexs.append(node.index)
                    node.offset_matrix = glm.mat4(*offset_mat_arr[joint_idx])
        
    def read_animation(self):
        if 'animations' not in self.parsed or len(self.parsed['animations']) <= 0:
            return
        anim_list = self.parsed['animations']
        for anim_d in anim_list:
            anim = Animation()
            self.animations.append(anim)
            anim.time = 0.0
            anim.weight = 1.0
            anim.name = anim_d['name']
            chan_list = anim_d['channels']
            sampler_list = anim_d['samplers']
            node_anim_d = {}
            for chan_d in chan_list:
                sampler_idx = chan_d['sampler']
                node_idx = chan_d['target']['node']
                path = chan_d['target']['path']
                sampler_d = sampler_list[sampler_idx]
                input_acce_idx = sampler_d['input']
                interpolation = sampler_d['interpolation']  # "LINEAR"
                output_acce_idx = sampler_d['output']
                anim_key = None
                if node_idx in node_anim_d:
                    anim_key = node_anim_d[node_idx]
                else:
                    anim_key = AnimationKey()
                    anim_key.node_idx = node_idx
                    anim_key.node = self.find_node(node_idx)
                    anim.keys.append(anim_key)
                    node_anim_d[node_idx] = anim_key
                # input
                time_arr, byte_len, count, elem_cnt, comp_type, max_data, min_data, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, input_acce_idx, False)
                if len(max_data) > 0:
                    anim.duration = max(anim.duration, max_data[0])
                # output
                path_arr, byte_len, count, elem_cnt, comp_type, max_data, min_data, stride, offset = glb_parser.get_buffer_data(self.parsed, self.body, output_acce_idx, False)
                path_arr = path_arr.reshape(count, elem_cnt)
                if path == 'translation':
                    anim_key.position_times = time_arr
                    anim_key.positions = path_arr
                elif path == 'rotation':
                    # [X, Y, Z, W] => [W, X, Y, Z]
                    rot_arr = np.zeros((count, elem_cnt), dtype=np.float32)
                    for rot_idx, rot in enumerate(path_arr):
                        rot_arr[rot_idx][0] = rot[3]
                        rot_arr[rot_idx][1] = rot[0]
                        rot_arr[rot_idx][2] = rot[1]
                        rot_arr[rot_idx][3] = rot[2]
                    anim_key.rotation_times = time_arr
                    anim_key.rotations = rot_arr
                elif path == 'scale':
                    anim_key.scale_times = time_arr
                    anim_key.scales = path_arr
            # キーフレームがなく初期値がある場合、初期値を設定する
            for node_idx in node_anim_d:
                anim_key = node_anim_d[node_idx]
                node = anim_key.node
                if len(anim_key.position_times) == 0 and node.translation:
                    anim_key.position_times = np.array([0.0], dtype=np.float32)
                    anim_key.positions = np.array([node.translation], dtype=np.float32)
                if len(anim_key.rotation_times) == 0 and node.rotation:
                    anim_key.rotation_times = np.array([0.0], dtype=np.float32)
                    anim_key.rotations = np.array([node.rotation], dtype=np.float32)
                if len(anim_key.scale_times) == 0 and node.scale:
                    anim_key.scale_times = np.array([0.0], dtype=np.float32)
                    anim_key.scales = np.array([node.scale], dtype=np.float32)
        
    def find_node(self, idx):
        for node in self.nodes:
             if node.node_index == idx:
                 return node
        return None
        
    def get_animation(self, index):
        if index < len(self.animations):
            return self.animations[index]
        else:
            return None
        
    def animate_node(self, world):
        # アニメーションキーが関係するフレームの変形行列を初期化
        for anim in self.animations:
            if anim.weight == 0.0: continue
            # 0で初期化
            for key in anim.keys:
                key.node.transform_matrix = glm.mat4(0.0)
        # アニメーションキーが関係するフレームの変形行列を計算
        for anim in self.animations:
            if anim.weight == 0.0: continue
            for key in anim.keys:
                node = key.node
                # キーフレームの補間
                time = anim.time
                trans, rot, scale = [glm.mat4(1.0)] * 3
                # Position
                if len(key.position_times) > 0:
                    if time < key.position_times[0]:
                        pos = key.positions[0]
                        trans = glm.translate(glm.mat4(1.0), glm.vec3(pos[0], pos[1], pos[2]))
                    elif time >= key.position_times[-1]:
                        pos = key.positions[-1]
                        trans = glm.translate(glm.mat4(1.0), glm.vec3(pos[0], pos[1], pos[2]))
                    else:
                        for k, _ in enumerate(key.position_times):
                            if time < key.position_times[k] and key.position_times[k - 1] != key.position_times[k]:
                                r = (key.position_times[k] - time) / (key.position_times[k] - key.position_times[k - 1])
                                pos1 = key.positions[k - 1]
                                pos2 = key.positions[k]
                                trans1 = glm.translate(glm.mat4(1.0), glm.vec3(pos1[0], pos1[1], pos1[2]))
                                trans2 = glm.translate(glm.mat4(1.0), glm.vec3(pos2[0], pos2[1], pos2[2]))
                                trans = (trans1 * r + trans2 * (1 - r))
                                break
                # Rotation
                if len(key.rotation_times) > 0:
                    if time < key.rotation_times[0]:
                        rot_ = key.rotations[0]
                        quat = glm.quat(rot_[0], rot_[1], rot_[2], rot_[3])
                        rot = glm.mat4_cast(quat)
                    elif time >= key.rotation_times[-1]:
                        rot_ = key.rotations[-1]
                        quat = glm.quat(rot_[0], rot_[1], rot_[2], rot_[3])
                        rot = glm.mat4_cast(quat)
                    else:
                        for k, _ in enumerate(key.rotation_times):
                            if time < key.rotation_times[k] and key.rotation_times[k - 1] != key.rotation_times[k]:
                                r = (key.rotation_times[k] - time) / (key.rotation_times[k] - key.rotation_times[k - 1])
                                rot_ = key.rotations[k - 1]
                                quat1 = glm.quat(rot_[0], rot_[1], rot_[2], rot_[3])
                                rot_ = key.rotations[k]
                                quat2 = glm.quat(rot_[0], rot_[1], rot_[2], rot_[3])
                                rot1 = glm.mat4_cast(quat1)
                                rot2 = glm.mat4_cast(quat2)
                                rot = (rot1 * r + rot2 * (1 - r))
                                break
                # Scale
                if len(key.scale_times) > 0:
                    if time < key.scale_times[0]:
                        sca = key.scales[0]
                        scale = glm.scale(glm.mat4(1.0), glm.vec3(sca[0], sca[1], sca[2]))
                    elif time >= key.scale_times[-1]:
                        sca = key.scales[-1]
                        scale = glm.scale(glm.mat4(1.0), glm.vec3(sca[0], sca[1], sca[2]))
                    else:
                        for k, _ in enumerate(key.scale_times):
                            if time < key.scale_times[k] and key.scale_times[k - 1] != key.scale_times[k]:
                                r = (key.scale_times[k] - time) / (key.scale_times[k] - key.scale_times[k - 1])
                                sca1 = key.scales[k - 1]
                                sca2 = key.scales[k]
                                scale1 = glm.scale(glm.mat4(1.0), glm.vec3(sca1[0], sca1[1], sca1[2]))
                                scale2 = glm.scale(glm.mat4(1.0), glm.vec3(sca2[0], sca2[1], sca2[2]))
                                scale = (scale1 * r + scale2 * (1 - r))
                                break
                matrix = trans * rot * scale
                node.transform_matrix += matrix * anim.weight
        # ボーンノードのスキニング行列を計算
        for root_node in self.root_nodes:
            root_node.animate(world)
        
    def get_skinning_matrix(self, mat):
        num_bone = len(mat.node_indexs)
        skin_mat = np.zeros((num_bone, 4, 4), dtype=np.float32)
        for i, node_index in enumerate(mat.node_indexs):
            node = self.nodes[node_index]
            skin_mat[i] = np.array(node.skinning_matrix, dtype=np.float32)
        return skin_mat

class Material:
    def __init__(self):
        self.has_position = False
        self.has_normal = False
        self.has_uv = False
        self.has_texture = False
        self.num_vertex = 0
        self.vertexs = []
        self.num_face = 0
        self.faces = []
        self.normals = []
        self.uvs = []
        self.pos_max = [0.0] * 3
        self.pos_min = [0.0] * 3
        self.pos_type_count = 3
        self.idx_type = None
        self.pos_type = None
        self.bone_id_type = None
        self.weight_type = None
        self.pos_elem_count = 0
        self.norm_elem_count = 0
        self.uv_elem_count = 0
        self.vao = None
        self.vbo_vertex = None
        self.vbo_normal = None
        self.vbo_tex_coord = None
        self.ibo_faces = None
        self.texture = None
        self.diffuse_color = [1.0] * 4
        self.alpha_mode = "OPAQUE"
        self.alpha_cutoff = 0.5
        self.transform_matrix = None
        self.max_pos = []
        self.min_pos = []
        self.pos_stride = 0
        self.norm_stride = 0
        self.uv_stride = 0
        self.bone_stride = 0
        self.weight_stride = 0
        self.pos_offset = 0
        self.norm_offset = 0
        self.uv_offset = 0
        self.bone_offset = 0
        self.weight_offset = 0
        # bone
        self.node_indexs = []  # GLB内のnodesのインデックスではなく、Model内のnodesのインデックス
        self.vbo_bone_id = None
        self.vbo_bone_weight = None

class Node:
    def __init__(self, name):
        self.name = name
        self.children = []
        self.index = -1
        self.node_index = -1
        self.mesh_index = -1
        self.translation = None
        self.rotation = None
        self.scale = None
        self.transform_matrix = glm.mat4(0.0)
        self.offset_matrix = glm.mat4(0.0)
        self.combined_matrix = glm.mat4()
        self.skinning_matrix = glm.mat4()
        
    def animate(self, parent):
        self.combined_matrix = parent * self.transform_matrix
        for child in self.children:
            child.animate(self.combined_matrix)
        self.skinning_matrix = self.combined_matrix * self.offset_matrix

class Animation:
    def __init__(self):
        self.name = ""
        self.duration = 0.0
        self.ticks_per_second = 0.0
        self.keys = []
        self.time = 0.0
        self.weight = 0.0

class AnimationKey:
    def __init__(self):
        self.position_times = []
        self.positions = []
        self.rotation_times = []
        self.rotations = []
        self.scale_times = []
        self.scales = []
        self.node_idx = -1
        self.node = None

def add_node(parentNode, nodes, node_d, nodes_list):
    child_node_idxs = []
    if 'children' in node_d:
        child_node_idxs = node_d['children']
    for idx in child_node_idxs:
        child_node_d = nodes_list[idx]
        #if 'mesh' in child_node_d:
        #    continue
        child_name = child_node_d['name']
        node = Node(child_name)
        node.index = len(nodes)
        node.node_index = idx
        parentNode.children.append(node)
        if 'mesh' in child_node_d:
            node.mesh_index = child_node_d['mesh']
        trans, rot, scale = [glm.mat4(1.0)] * 3
        if 'translation' in child_node_d:
            pos = child_node_d['translation']
            trans = glm.translate(glm.mat4(1.0), glm.vec3(pos[0], pos[1], pos[2]))
            node.translation = pos
        if 'rotation' in child_node_d:
            rot_ = child_node_d['rotation']
            quat = glm.quat(rot_[3], rot_[0], rot_[1], rot_[2])
            rot = glm.mat4_cast(quat)
            node.rotation = rot_
        if 'scale' in child_node_d:
            sca = child_node_d['scale']
            scale = glm.scale(glm.mat4(1.0), glm.vec3(sca[0], sca[1], sca[2]))
            node.scale = sca
        node.transform_matrix = trans * rot * scale
        nodes.append(node)
        add_node(node, nodes, child_node_d, nodes_list)

def interate_skeleton_node(node, indent_level=0):
    yield (node, indent_level)
    indent_level += 1
    for child_node in node.children:
        for child_node2, indent_level2 in interate_skeleton_node(child_node, indent_level):
            yield (child_node2, indent_level2)

def show_skeleton_tree(root_node):
    for node, indent_level in interate_skeleton_node(root_node):
        print("{}-{} ({})".format(" "*indent_level*2, node.name, node.node_index))

if __name__ == "__main__":
    reader = GlbReader('data/simple_anim.glb')
    parsed, body = reader.model.parsed, reader.model.body
    print(parsed.keys())
