from OpenGL.GL import *
import glfw
import numpy as np
import my_glm as glm
import cube_shader
from trackball import Trackball
import gl_util

tb = None
aspect_ratio = 1.0
fb = None
fb_tex = None
render_program = None
pick_program = None
edge_vao = None
face_vao = None
pick_vao = None
face_num_vertex = 0
edge_num_vertex = 0
mouse_pos = (0, 0)
is_picked = False
pick_id = 0

vertex_shader_src="""
#version 400 core

in vec3 position;
flat out uint vertex_id;
uniform mat4 P, V, M;

void main(void) {
    vertex_id = gl_VertexID;
    gl_Position = P * V * M * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

flat in uint vertex_id;
out vec4 outFragmentColor;
uniform vec3 color;
uniform int pick_id;
uniform int hober_id;

void main(void) {
    uint face_id = vertex_id / 3 + 1;
    if (face_id == hober_id) {
        outFragmentColor = vec4(1.0, 0.0, 1.0, 1.0);
    } else if (face_id == pick_id) {
        outFragmentColor = vec4(1.0, 1.0, 0.0, 1.0);
    } else {
        outFragmentColor = vec4(color, 1.0);
    }
}
""".strip()

pick_vertex_shader_src="""
#version 400 core

in vec3 position;
in uint color_code;
flat out uint fr_color_code;
uniform mat4 P, V, M;

void main(void) {
    fr_color_code = color_code;
    gl_Position = P * V * M * vec4(position, 1.0);
}
""".strip()

pick_fragment_shader_src="""
#version 400 core

flat in uint fr_color_code;
out uint outFragmentColor;

void main(void) {
    outFragmentColor = fr_color_code;
}
""".strip()

def encode_id(id_):
    r = id_ // 65536
    g = (id_ - r * 65536) // 256
    b = id_ - r * 65536 - g * 256
    return [r / 255.0, g / 255.0, b / 255.0]

def decode_id(r, g, b):
    return b + g * 256 + r * 256 * 256

# 2つ目のフレームバッファを初期化します。
# これにより、メインシーンを直接画面にレンダリングするのではなく、テクスチャにレンダリングできます。
# フレームバッファの作成で問題が発生した場合は None を返します
def create_fbo(width, height):
    fb = glGenFramebuffers(1)
    # fb にアタッチされるテクスチャを作成します。 ビューポートと同じ寸法にする必要があります
    fb_tex = glGenTextures(1)
    glBindTexture( GL_TEXTURE_2D, fb_tex )
    glTexImage2D( GL_TEXTURE_2D, 0, GL_R32UI, width, height, 0, GL_RED_INTEGER, GL_UNSIGNED_INT, None)
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT )
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT )
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST )
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST )
    # テクスチャをフレームバッファにアタッチします
    glBindFramebuffer( GL_FRAMEBUFFER, fb )
    glFramebufferTexture2D( GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, fb_tex, 0 )
    # フレームバッファで深度テストを可能にするレンダバッファを作成します
    rb = glGenRenderbuffers(1)
    glBindRenderbuffer( GL_RENDERBUFFER, rb )
    glRenderbufferStorage( GL_RENDERBUFFER, GL_DEPTH_COMPONENT, width, height )
    # レンダバッファをフレームバッファにアタッチします
    glFramebufferRenderbuffer( GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, rb )
    # フレームバッファーにカラー出力アタッチメント（テクスチャ）を設定します
    draw_bufs = [GL_COLOR_ATTACHMENT0]
    glDrawBuffers(1, draw_bufs)
    
    # フレームバッファーを検証します-「不完全な」エラーは、
    # 無効な画像フォーマットが添付されているか、glDrawBuffers 情報が無効であるかを示します
    status = glCheckFramebufferStatus( GL_FRAMEBUFFER )
    if GL_FRAMEBUFFER_COMPLETE != status:
        print("ERROR: incomplete framebuffer")
        if GL_FRAMEBUFFER_UNDEFINED == status:
            print("GL_FRAMEBUFFER_UNDEFINED")
        elif GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT == status:
            print("GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT")
        elif GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT == status:
            print("GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT")
        elif GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER == status:
            print("GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER")
        elif GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER == status:
            print("GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER")
        elif GL_FRAMEBUFFER_UNSUPPORTED == status:
            print("GL_FRAMEBUFFER_UNSUPPORTED")
        elif GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE == status:
            print("GL_FRAMEBUFFER_INCOMPLETE_MULTISAMPLE")
        elif GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS == status:
            print("GL_FRAMEBUFFER_INCOMPLETE_LAYER_TARGETS")
        else:
            print("unspecified error")
        return None, None
    
    # 安全策としてデフォルトのフレームバッファを再バインドします
    glBindFramebuffer(GL_FRAMEBUFFER, 0)
    return fb, fb_tex

def create_vbo():
    # face
    face_positions, face_normals = cube_shader.get_cube_triangles()
    face_num_vertex = face_positions.size // 3
    face_pos_vbo = gl_util.create_vbo(face_positions)
    # edge
    edge_positions = cube_shader.get_cube_lines()
    edge_num_vertex = edge_positions.size // 3
    edge_pos_vbo = gl_util.create_vbo(edge_positions)
    # color code
    color_codes = []
    for i in range(face_num_vertex // 3):
        code = i + 1
        color_codes.append(code)
        color_codes.append(code)
        color_codes.append(code)
    color_codes = np.array(color_codes, dtype=np.uint32)
    color_code_vbo = gl_util.create_vbo(color_codes)
    return face_pos_vbo, edge_pos_vbo, face_num_vertex, edge_num_vertex, color_code_vbo

def create_render_vao(program, pos_vbo):
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    
    pos_loc = glGetAttribLocation(program, "position")
    glEnableVertexAttribArray(pos_loc)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)
    
    return vao

def create_pick_vao(program, face_pos_vbo, color_code_vbo):
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    
    pos_loc = glGetAttribLocation(program, "position")
    glEnableVertexAttribArray(pos_loc)
    glBindBuffer(GL_ARRAY_BUFFER, face_pos_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    
    color_code_loc = glGetAttribLocation(program, "color_code")
    glEnableVertexAttribArray(color_code_loc)
    glBindBuffer(GL_ARRAY_BUFFER, color_code_vbo)
    glVertexAttribIPointer(color_code_loc, 1, GL_UNSIGNED_INT, 0, None)
    
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)
    
    return vao

def init(window, width, height):
    global tb, aspect_ratio
    global fb, fb_tex
    global render_program, pick_program, edge_vao, face_vao, pick_vao
    global face_num_vertex, edge_num_vertex
    aspect_ratio = width / height
    # トラックボールの初期化
    tb = Trackball()
    tb.region(SCREEN_WIDTH, SCREEN_HEIGHT)
    # FBO の初期化
    fb, fb_tex = create_fbo(width, height)
    # シェーダの初期化
    render_program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    face_pos_vbo, edge_pos_vbo, face_num_vertex, edge_num_vertex, color_code_vbo = create_vbo()
    face_vao = create_render_vao(render_program, face_pos_vbo)
    edge_vao = create_render_vao(render_program, edge_pos_vbo)
    pick_program = gl_util.create_program(pick_vertex_shader_src, pick_fragment_shader_src)
    pick_vao = create_pick_vao(pick_program, face_pos_vbo, color_code_vbo)
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, 0.1, 10.0)
    P = np.array(P, dtype=np.float32)
    V = glm.lookAt(glm.vec3(0.0, 0.0, 5.0), glm.vec3(0.0, 0.0, 0.0), glm.vec3(0.0, 1.0, 0.0))
    V = np.array(V, dtype=np.float32)
    glUseProgram(render_program)
    P_loc = glGetUniformLocation(render_program, "P")
    glUniformMatrix4fv(P_loc, 1, GL_FALSE, P)
    V_loc = glGetUniformLocation(render_program, "V")
    glUniformMatrix4fv(V_loc, 1, GL_FALSE, V)
    glUseProgram(pick_program)
    P_loc = glGetUniformLocation(pick_program, "P")
    glUniformMatrix4fv(P_loc, 1, GL_FALSE, P)
    V_loc = glGetUniformLocation(pick_program, "V")
    glUniformMatrix4fv(V_loc, 1, GL_FALSE, V)
    glUseProgram(0)

def update(window, width, height):
    global mouse_pos, is_picked
    x, y = glfw.get_cursor_pos(window)
    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.PRESS and not tb.is_rotating():
        tb.start(x, y)
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.RELEASE:
        tb.stop()
    x, y = glfw.get_cursor_pos(window)
    tb.motion(x, y)
    mouse_pos = (x, height - y)
    is_picked = False
    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_2) == glfw.PRESS:
        is_picked = True

def draw_render(hober_id, pick_id):
    glUseProgram(render_program)
    # M
    M = tb.get()
    M_loc = glGetUniformLocation(render_program, "M")
    glUniformMatrix4fv(M_loc, 1, GL_FALSE, M)
    # hober_id
    hober_id_loc = glGetUniformLocation(render_program, "hober_id")
    glUniform1i(hober_id_loc, hober_id)
    # pick_id
    pick_id_loc = glGetUniformLocation(render_program, "pick_id")
    glUniform1i(pick_id_loc, pick_id)
    # draw face
    color_loc = glGetUniformLocation(render_program, "color")
    glUniform3f(color_loc, 1.0, 0.0, 0.0)
    glBindVertexArray(face_vao)
    glDrawArrays(GL_TRIANGLES, 0, face_num_vertex)
    glBindVertexArray(0)
    # draw edge
    glBindVertexArray(edge_vao)
    glUniform1i(hober_id_loc, 0)
    glUniform1i(pick_id_loc, 0)
    glUniform3f(color_loc, 1.0, 1.0, 1.0)
    glDrawArrays(GL_LINES, 0, edge_num_vertex)
    glBindVertexArray(0)
    glUseProgram(0)

def draw_pick_color():
    glBindFramebuffer(GL_FRAMEBUFFER, fb)
    glClearColor(0.0, 0.0, 0.0, 1.0)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glUseProgram(pick_program)
    # M
    M = tb.get()
    M_loc = glGetUniformLocation(pick_program, "M")
    glUniformMatrix4fv(M_loc, 1, GL_FALSE, M)
    # draw color code
    glBindVertexArray(pick_vao)
    glDrawArrays(GL_TRIANGLES, 0, face_num_vertex)
    glBindVertexArray(0)
    glUseProgram(0)
    glBindFramebuffer(GL_FRAMEBUFFER, 0)

def draw():
    global pick_id
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_POLYGON_OFFSET_FILL)
    glPolygonOffset(1.0, 1.0)
    draw_pick_color()
    # check mouse picking
    glBindFramebuffer(GL_FRAMEBUFFER, fb)
    hober_id = 0
    mx = mouse_pos[0]
    my = mouse_pos[1]
    data = glReadPixels(mx, my, 1, 1, GL_RED_INTEGER, GL_UNSIGNED_INT)
    hober_id = data[0][0]
    
    if is_picked:
        pick_id = hober_id
    glBindFramebuffer( GL_FRAMEBUFFER, 0 )
    draw_render(hober_id, pick_id)
    glDisable(GL_DEPTH_TEST)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
