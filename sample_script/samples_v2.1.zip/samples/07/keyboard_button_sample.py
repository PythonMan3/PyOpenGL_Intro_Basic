from OpenGL.GL import *
from OpenGL.GLU import *
import glfw

def keyboard(window, key, scancode, action, mods):
    if key == glfw.KEY_Z and action == glfw.PRESS:    # Z キーが押された場合
        if mods == glfw.MOD_CONTROL:                  # Ctrl キーを押しながら Z キーが押された場合
            print("Z Key Pressed with Ctrl")
        elif mods == glfw.MOD_SHIFT:                  # Shift キーを押しながら Z キーが押された場合
            print("Z Key Pressed with Shift")
        else:
            print("Z Key Pressed")
    elif key == glfw.KEY_X and action == glfw.PRESS:  # X キーが押された場合
        print("X Key Pressed")

def init(window, width, height):
    glfw.set_key_callback(window, keyboard)

def update(window, width, height):
    if glfw.get_key(window, glfw.KEY_SPACE) == glfw.PRESS:     # スペースキーが押された場合
        print("Space Key Pressed")
    elif glfw.get_key(window, glfw.KEY_ESCAPE) == glfw.PRESS:  # エスケープキーが押された場合
        print("Escape Key Pressed")
    elif glfw.get_key(window, glfw.KEY_DOWN) == glfw.PRESS:    # 矢印キーの下が押された場合
        print("Down Key Pressed")
    elif glfw.get_key(window, glfw.KEY_LEFT) == glfw.PRESS:    # 矢印キーの左が押された場合
        print("Left Key Pressed")
    elif glfw.get_key(window, glfw.KEY_RIGHT) == glfw.PRESS:   # 矢印キーの右が押された場合
        print("Right Key Pressed")
    elif glfw.get_key(window, glfw.KEY_UP) == glfw.PRESS:      # 矢印キーの上が押された場合
        print("Up Key Pressed")
    elif glfw.get_key(window, glfw.KEY_KP_2) == glfw.PRESS:    # キーパッドの2が押された場合
        print("Keypad 2 Pressed")
    elif glfw.get_key(window, glfw.KEY_KP_4) == glfw.PRESS:    # キーパッドの4が押された場合
        print("Keypad 4 Pressed")
    elif glfw.get_key(window, glfw.KEY_KP_6) == glfw.PRESS:    # キーパッドの6が押された場合
        print("Keypad 6 Pressed")
    elif glfw.get_key(window, glfw.KEY_KP_8) == glfw.PRESS:    # キーパッドの8が押された場合
        print("Keypad 8 Pressed")

def draw():
    pass

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
