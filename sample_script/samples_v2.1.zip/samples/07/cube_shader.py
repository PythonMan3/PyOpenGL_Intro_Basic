from OpenGL.GL import *
import glfw
import numpy as np
import math
import my_glm as glm
import gl_util
from trackball import Trackball

vertexs = [
    [-0.5, -0.5, -0.5],  # 0
    [-0.5, -0.5, 0.5],   # 1
    [-0.5, 0.5, 0.5],    # 2
    [-0.5, 0.5, -0.5],   # 3
    [0.5, -0.5, -0.5],   # 4
    [0.5, -0.5, 0.5],    # 5
    [0.5, 0.5, 0.5],     # 6
    [0.5, 0.5, -0.5]]    # 7

faces = [
    [0, 1, 2],  # 左面
    [0, 2, 3],  # 左面
    [0, 3, 7],  # 後面
    [0, 7, 4],  # 後面
    [0, 4, 5],  # 下面
    [0, 5, 1],  # 下面
    [6, 5, 4],  # 右面
    [6, 4, 7],  # 右面
    [6, 7, 3],  # 上面
    [6, 3, 2],  # 上面
    [6, 2, 1],  # 前面
    [6, 1, 5]]  # 前面

edges = [
    [0, 1],
    [1, 2],
    [2, 3],
    [3, 0],
    [4, 5],
    [5, 6],
    [6, 7],
    [7, 4],
    [0, 4],
    [1, 5],
    [3, 7],
    [2, 6]]

tb = None
aspect_ratio = 1.0
program = None
edge_vao = None
face_vao = None
face_num_vertex = 0
edge_num_vertex = 0

def norm(vec):
    len = math.sqrt(vec[0]*vec[0] + vec[1]*vec[1] + vec[2]*vec[2])
    return [vec[0]/len, vec[1]/len, vec[2]/len]

def cross_vec(vec1, vec2):
    return [
        vec1[1]*vec2[2] - vec1[2]*vec2[1],
        vec1[2]*vec2[0] - vec1[0]*vec2[2],
        vec1[0]*vec2[1] - vec1[1]*vec2[0]]

def get_cube_triangles():
    trias = []
    norms = []
    colors = []
    for idxs in faces:
        vertex1, vertex2, vertex3 = vertexs[idxs[0]], vertexs[idxs[1]], vertexs[idxs[2]]
        trias.append([vertex1, vertex2, vertex3])
        vec1 = [vertex2[0] - vertex1[0], vertex2[1] - vertex1[1], vertex2[2] - vertex1[2]]
        vec2 = [vertex3[0] - vertex1[0], vertex3[1] - vertex1[1], vertex3[2] - vertex1[2]]
        vec1 = norm(vec1)
        vec2 = norm(vec2)
        vec3 = cross_vec(vec1, vec2)
        vec3 = norm(vec3)
        norms.append([vec3, vec3, vec3])
        #vertex_colors = face_color[i*3+0], face_color[i*3+1], face_color[i*3+2]
        #colors.append([vertex_colors, vertex_colors, vertex_colors])
    cube_trias = np.array(trias, dtype=np.float32)
    cube_norms = np.array(norms, dtype=np.float32)
    #cube_colors = np.array(colors, dtype=np.float32)
    return cube_trias, cube_norms

def get_cube_lines():
    lines = []
    for idxs in edges:
        vertex1, vertex2 = vertexs[idxs[0]], vertexs[idxs[1]]
        lines.append([vertex1, vertex2])
    cube_lines = np.array(lines, dtype=np.float32)
    return cube_lines

def get_cube_positions():
    cube_position = np.array(vertexs, dtype=np.float32)
    return cube_position

def get_cube_edges():
    cube_edges = np.array(edges, dtype=np.uint)
    return cube_edges

vertex_shader_src="""
#version 400 core

in vec3 position;
uniform mat4 P, V, M;

void main(void) {
    gl_Position = P * V * M * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

uniform vec3 color;
out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = vec4(color, 1.0);
}
""".strip()

def create_vbo(vertex):
    if not isinstance(vertex, np.ndarray):
        vertex = np.array(vertex, dtype=np.float32)
    vbo = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, vbo)
    glBufferData(GL_ARRAY_BUFFER, vertex.nbytes, vertex, GL_STATIC_DRAW)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    return vbo
    
def create_face_and_edge_vbo():
    face_positions, face_normals = get_cube_triangles()
    face_num_vertex = face_positions.size // 3
    face_pos_vbo = gl_util.create_vbo(face_positions)
    edge_positions = get_cube_lines()
    edge_num_vertex = edge_positions.size // 3
    edge_pos_vbo = gl_util.create_vbo(edge_positions)
    return face_pos_vbo, edge_pos_vbo, face_num_vertex, edge_num_vertex

def create_vao(program, face_pos_vbo):
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    pos_loc = glGetAttribLocation(program, "position")
    glEnableVertexAttribArray(pos_loc)
    glBindBuffer(GL_ARRAY_BUFFER, face_pos_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)
    return vao

def init(window, width, height):
    global tb, aspect_ratio
    global program, edge_vao, face_vao
    global face_num_vertex, edge_num_vertex
    aspect_ratio = width / height
    tb = Trackball()
    tb.region(width, height)
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    face_pos_vbo, edge_pos_vbo, face_num_vertex, edge_num_vertex = create_face_and_edge_vbo()
    face_vao = create_vao(program, face_pos_vbo)
    edge_vao = create_vao(program, edge_pos_vbo)
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, 0.1, 10.0)
    P = np.array(P, dtype=np.float32)
    V = glm.lookAt(glm.vec3(0.0, 0.0, 5.0), glm.vec3(0.0, 0.0, 0.0), glm.vec3(0.0, 1.0, 0.0))
    V = np.array(V, dtype=np.float32)
    glUseProgram(program)
    P_loc = glGetUniformLocation(program, "P")
    glUniformMatrix4fv(P_loc, 1, GL_FALSE, P)
    V_loc = glGetUniformLocation(program, "V")
    glUniformMatrix4fv(V_loc, 1, GL_FALSE, V)
    glUseProgram(0)

def update(window, width, height):
    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.PRESS and not tb.is_rotating():
        x, y = glfw.get_cursor_pos(window)
        tb.start(x, y)
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.RELEASE:
        tb.stop()
    x, y = glfw.get_cursor_pos(window)
    tb.motion(x, y)

def draw(face_color=(1.0, 0.0, 0.0), edge_color=(1.0, 1.0, 1.0), draw_edge=True):
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_POLYGON_OFFSET_FILL)
    glPolygonOffset(1.0, 1.0)
    glUseProgram(program)
    # M
    M = tb.get()
    M_loc = glGetUniformLocation(program, "M")
    glUniformMatrix4fv(M_loc, 1, GL_FALSE, M)
    # draw face
    color_loc = glGetUniformLocation(program, "color")
    glBindVertexArray(face_vao)
    glUniform3fv(color_loc, 1, face_color)
    glDrawArrays(GL_TRIANGLES, 0, face_num_vertex)
    glBindVertexArray(0)
    # draw edge
    if draw_edge:
        glBindVertexArray(edge_vao)
        glUniform3fv(color_loc, 1, edge_color)
        glDrawArrays(GL_LINES, 0, face_num_vertex)
        glBindVertexArray(0)
        glUseProgram(0)
    glDisable(GL_DEPTH_TEST)
    glDisable(GL_POLYGON_OFFSET_FILL)
