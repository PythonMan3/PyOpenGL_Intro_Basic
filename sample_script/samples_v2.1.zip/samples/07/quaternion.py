import my_glm as glm
import numpy as np

def toVec3(vec, qtn):
    qp = glm.quat()
    qq = glm.quat()
    qr = glm.conjugate(qtn)
    qp[0] = vec[0]
    qp[1] = vec[1]
    qp[2] = vec[2]
    qq = qr * qp
    qr = qq * qtn
    dest = np.zeros(3)
    dest[0] = qr[0]
    dest[1] = qr[1]
    dest[2] = qr[2]
    return dest

def toMat4(qtn):
    x = qtn[0]
    y = qtn[1]
    z = qtn[2]
    w = qtn[3]
    x2 = x + x
    y2 = y + y
    z2 = z + z
    xx = x * x2
    xy = x * y2
    xz = x * z2
    yy = y * y2
    yz = y * z2
    zz = z * z2
    wx = w * x2
    wy = w * y2
    wz = w * z2
    dest = np.zeros(16)
    dest[0]  = 1 - (yy + zz)
    dest[1]  = xy + wz
    dest[2]  = xz - wy
    dest[3] = 0
    dest[4]  = xy - wz
    dest[5]  = 1 - (xx + zz)
    dest[6]  = yz + wx
    dest[7] = 0
    dest[8]  = xz + wy
    dest[9]  = yz - wx
    dest[10] = 1 - (xx + yy)
    dest[11] = 0
    dest[12]  = 0
    dest[13]  = 0
    dest[14] = 0
    dest[15] = 1
    return dest.reshape(4, 4)
