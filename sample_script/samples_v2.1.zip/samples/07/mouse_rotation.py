from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import my_glm as glm
import gl_util
import cube_shader

is_rot = False
start_x = None
start_y = None
start_qtn = None
mdl_qtn = glm.quat()
mdl_rot = None
aspect_ratio = 1.0
program = None
edge_vao = None
face_vao = None

vertex_shader_src="""
#version 400 core

layout(location = 0) in vec3 position;
uniform mat4 MVP;

void main(void) {
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

uniform vec3 color;
out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = vec4(color, 1.0);
}
""".strip()

def create_vao(program, pos_vbo):
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)

    glEnableVertexAttribArray(0)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)

    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)
    glDisableVertexAttribArray(0)

    return vao

def init(window, width, height):
    global mdl_rot, aspect_ratio
    global program, edge_vao, face_vao
    global face_num_vertex, edge_num_vertex
    aspect_ratio = width / height
    # モデル用回転行列の初期化
    mdl_rot = glm.mat4_cast(mdl_qtn)  # クォータニオンを4x4行列に変換
    mdl_rot = np.array(mdl_rot)       # glm.mat4x4 を numpy.ndarray に変換
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    face_positions, face_normals = cube_shader.get_cube_triangles()
    edge_positions = cube_shader.get_cube_lines()
    face_pos_vbo = gl_util.create_vbo(face_positions)
    edge_pos_vbo = gl_util.create_vbo(edge_positions)
    face_vao = create_vao(program, face_pos_vbo)
    edge_vao = create_vao(program, edge_pos_vbo)

def update(window, width, height):
    global start_x, start_y
    global start_qtn, mdl_qtn, mdl_rot
    global is_rot
    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.PRESS and not is_rot:
        # ドラッグによるモデルの回転開始
        # 開始位置と開始時のクォータニオンの記録
        x, y = glfw.get_cursor_pos(window)
        start_x = x
        start_y = y
        start_qtn = glm.quat(mdl_qtn)
        is_rot = True
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_1) == glfw.RELEASE:
        is_rot = False
    # モデルの回転
    if is_rot:
        x, y = glfw.get_cursor_pos(window)
        # マウス位置は左上原点
        dx = x - start_x
        dy = y - start_y
        
        # ドラッグ開始位置からの変位（ラジアン換算)
        # 横方向はウィンドウ幅が一周分、縦方向はウィンドウ高さが一周分
        # 下方向のマウス移動は+X軸回転、右方向のマウス移動は+Y軸回転
        axis = [0.0] * 3
        axis[0] = 2.0 * glm.pi() * dy / float(height)
        axis[1] = 2.0 * glm.pi() * dx / float(width)
        axis[2] = 0.0
        
        # ドラッグ開始位置からの回転角度、同時に回転軸を正規化
        rot = np.linalg.norm(axis)  # ラジアン
        if rot == 0.0:
            return
        axis = axis / rot
        
        # ドラッグ開始位置からの差分を元に回転クォータニオンを生成
        dqtn = glm.rotate(glm.quat(), rot, glm.vec3(axis))
       
        # 回転クォータニオンを合成
        mdl_qtn = dqtn * start_qtn
        
        # クォータニオンからマトリックスに変換
        mdl_rot = np.array(glm.mat4_cast(mdl_qtn))

def draw():
    glEnable(GL_DEPTH_TEST)
    glEnable(GL_POLYGON_OFFSET_FILL)
    glPolygonOffset(1.0, 1.0)
    glUseProgram(program)
    # MVP
    M = glm.mat4(mdl_rot)
    V = glm.lookAt(glm.vec3(0.0, 0.0, 5.0), glm.vec3(0.0, 0.0, 0.0), glm.vec3(0.0, 1.0, 0.0))
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, 0.1, 10.0)
    MVP = np.array(P * V * M, dtype=np.float32)
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    # draw face
    color_loc = glGetUniformLocation(program, "color")
    glBindVertexArray(face_vao)
    glUniform3f(color_loc, 1.0, 0.0, 0.0)
    face_positions, face_normals = cube_shader.get_cube_triangles()
    face_num_vertex = face_positions.size // 3
    glDrawArrays(GL_TRIANGLES, 0, face_num_vertex)
    # draw edge
    glBindVertexArray(edge_vao)
    glUniform3f(color_loc, 1.0, 1.0, 1.0)
    edge_positions = cube_shader.get_cube_lines()
    edge_num_vertex = edge_positions.size // 3
    glDrawArrays(GL_LINES, 0, edge_num_vertex)
    glBindVertexArray(0)
    glUseProgram(0)
    glDisable(GL_DEPTH_TEST)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
