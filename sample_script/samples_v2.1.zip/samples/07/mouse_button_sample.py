from OpenGL.GL import *
from OpenGL.GLU import *
import glfw

button_presseds = [False] * 3

def mouse_button(window, button, action, mods):
    if button == glfw.MOUSE_BUTTON_LEFT and action == glfw.PRESS:  # マウスの左ボタンが押された場合
        print("Left Button Pressed by Callback")

def init(window, width, height):
    glfw.set_mouse_button_callback(window, mouse_button)

def update(window, width, height):
    if glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_LEFT) == glfw.PRESS and not button_presseds[0]:    # マウスの左ボタンが押された場合
        print("Left Button Pressed")
        button_presseds[0] = True
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_RIGHT) == glfw.PRESS and not button_presseds[1]:  # マウスの右ボタンが押された場合
        print("Right Button Pressed")
        button_presseds[1] = True
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_MIDDLE) == glfw.PRESS and not button_presseds[2]:  # マウスの中ボタンが押された場合
        print("Middle Button Pressed")
        button_presseds[2] = True
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_LEFT) == glfw.RELEASE and button_presseds[0]:    # マウスの左ボタンが離された場合
        print("Left Button Released")
        button_presseds[0] = False
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_RIGHT) == glfw.RELEASE and button_presseds[1]:    # マウスの右ボタンが離された場合
        print("Right Button Released")
        button_presseds[1] = False
    elif glfw.get_mouse_button(window, glfw.MOUSE_BUTTON_MIDDLE) == glfw.RELEASE and button_presseds[2]:    # マウスの中ボタンが離された場合
        print("Middle Button Released")
        button_presseds[2] = False

def draw():
    pass

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
