from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np

def init(window, width, height):
    present =  glfw.joystick_present(glfw.JOYSTICK_1)
    name = glfw.get_joystick_name(glfw.JOYSTICK_1)
    print('present={}, name={}'.format(present, name))

def update(window, width, height):
    if glfw.joystick_is_gamepad(glfw.JOYSTICK_1):
        state = glfw.get_gamepad_state(glfw.JOYSTICK_1)
        if state.buttons[glfw.GAMEPAD_BUTTON_A]:
            print('A pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_B]:
            print('B pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_X]:
            print('X pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_Y]:
            print('Y pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_LEFT_BUMPER]:
            print('Left Bumper pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_RIGHT_BUMPER]:
            print('Right Bumper pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_BACK]:
            print('Back pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_START]:
            print('Start pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_GUIDE]:
            print('Guide pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_LEFT_THUMB]:
            print('Left Thumb pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_RIGHT_THUMB]:
            print('Right Thumb pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_DPAD_UP]:
            print('Dpad Up pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_DPAD_RIGHT]:
            print('Dpad Right pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_DPAD_DOWN]:
            print('Dpad Down pressed')
        elif state.buttons[glfw.GAMEPAD_BUTTON_DPAD_LEFT]:
            print('Dpad Left pressed')
        elif abs(state.axes[glfw.GAMEPAD_AXIS_LEFT_X]) >= 0.5:
            print('AXIS_LEFT_X={}'.format(state.axes[glfw.GAMEPAD_AXIS_LEFT_X]))
        elif abs(state.axes[glfw.GAMEPAD_AXIS_LEFT_Y]) >= 0.5:
            print('AXIS_LEFT_Y={}'.format(state.axes[glfw.GAMEPAD_AXIS_LEFT_Y]))
        elif abs(state.axes[glfw.GAMEPAD_AXIS_RIGHT_X]) >= 0.5:
            print('AXIS_RIGHT_X={}'.format(state.axes[glfw.GAMEPAD_AXIS_RIGHT_X]))
        elif abs(state.axes[glfw.GAMEPAD_AXIS_RIGHT_Y]) >= 0.5:
            print('AXIS_RIGHT_Y={}'.format(state.axes[glfw.GAMEPAD_AXIS_RIGHT_Y]))
        elif state.axes[glfw.GAMEPAD_AXIS_LEFT_TRIGGER] >= 0.5:
            print('AXIS_LEFT_TRIGGER={}'.format(state.axes[glfw.GAMEPAD_AXIS_LEFT_TRIGGER]))
        elif state.axes[glfw.GAMEPAD_AXIS_RIGHT_TRIGGER] >= 0.5:
            print('AXIS_RIGHT_TRIGGER={}'.format(state.axes[glfw.GAMEPAD_AXIS_RIGHT_TRIGGER]))
    else:
        buttons, button_num = glfw.get_joystick_buttons(glfw.JOYSTICK_1)
        axiss, axis_num   = glfw.get_joystick_axes(glfw.JOYSTICK_1)
        buttons = buttons[:button_num]
        axiss = axiss[:axis_num]
        print('buttons={}'.format(buttons))
        print('axiss={}'.format(axiss))

def draw():
    pass

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
