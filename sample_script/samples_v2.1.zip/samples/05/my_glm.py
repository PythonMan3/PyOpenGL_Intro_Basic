import numpy as np

class vec3(np.ndarray):
    def __new__(cls, *args):
        if len(args) == 1 and isinstance(args[0], (int, float, np.float32)):
            return np.array([args[0]] * 3, dtype=np.float32).view(cls)
        elif len(args) == 1 and isinstance(args[0], (list, np.ndarray)):
            return np.array(args[0], dtype=np.float32).view(cls)
        elif len(args) == 3:
            return np.array(args, dtype=np.float32).view(cls)
        else:
            raise ValueError("Invalid arguments")
            
    @property
    def x(self):
        return self[0]
    
    @property
    def y(self):
        return self[1]
    
    @property
    def z(self):
        return self[2]
        
    @property
    def xyz(self):
        return [self[0], self[1], self[2]]
        
    def __str__(self):
        return f"vec3( {self[0]}, {self[1]}, {self[2]} )"
        
    def __repr__(self):
        return self.__str__()

class vec4(np.ndarray):
    def __new__(cls, *args):
        if len(args) == 1 and isinstance(args[0], (int, float, np.float32)):
            return np.array([args[0]] * 4, dtype=np.float32).view(cls)
        elif len(args) == 1 and isinstance(args[0], (list, np.ndarray)):
            return np.array(args[0], dtype=np.float32).view(cls)
        elif len(args) == 2 and isinstance(args[0], vec3) and isinstance(args[1], (int, float, np.float32)):
            data = [args[0][0], args[0][1], args[0][2], args[1]]
            return np.array(data, dtype=np.float32).view(cls)
        elif len(args) == 4:
            return np.array(args, dtype=np.float32).view(cls)
        else:
            raise ValueError("Invalid arguments")
        
    def __add__(self, other):
        if isinstance(other, vec4):
            new_vec4 = np.array(self) + np.array(other)
            return vec4(new_vec4)
        else:
            raise ValueError("Invalid operand")
        
    @property
    def x(self):
        return self[0]
    
    @property
    def y(self):
        return self[1]
    
    @property
    def z(self):
        return self[2]
        
    @property
    def w(self):
        return self[3]
        
    @property
    def xyz(self):
        return [self[0], self[1], self[2]]
        
    def __str__(self):
        return f"vec4( {self[0]}, {self[1]}, {self[2]}, {self[3]} )"
        
    def __repr__(self):
        return self.__str__()

class mat3x3(np.ndarray):
    def __new__(cls, *args):
        data = None
        if len(args) == 1:
            data = args[0]
        elif len(args) >= 2:
            data = np.array(args).reshape(3, 3)
        if data is None:
            data = np.identity(3, dtype=np.float32)
        elif isinstance(data, (int, float, np.float32)):
            data = np.eye(3) * data
        return np.array(data, dtype=np.float32).view(cls)
        
    def __getitem__(self, index):
        item = super().__getitem__(index)
        if isinstance(item, np.ndarray) and item.shape == (3,):
            return vec3(item)
        return item
    
    def __str__(self):
        return f"mat3x3( {self[0][0]}, {self[0][1]}, {self[0][2]} | " + \
            f"{self[1][0]}, {self[1][1]}, {self[1][2]} | " + \
            f"{self[2][0]}, {self[2][1]}, {self[2][2]} )"
        
    def __repr__(self):
        return self.__str__()

class mat4x4(np.ndarray):
    def __new__(cls, *args):
        data = None
        if len(args) == 1:
            data = args[0]
        elif len(args) >= 2:
            data = np.array(args).reshape(4, 4)
        if data is None:
            data = np.identity(4, dtype=np.float32)
        elif isinstance(data, (int, float, np.float32)):
            data = np.eye(4) * data
        elif isinstance(data, mat3x3):
            data4 = np.identity(4, dtype=np.float32)
            data4[0] = [*data[0], 0]
            data4[1] = [*data[1], 0]
            data4[2] = [*data[2], 0]
            data4[3] = [0, 0, 0, 1]
            data = data4
        return np.array(data, dtype=np.float32).view(cls)
        
    def __getitem__(self, index):
        item = super().__getitem__(index)
        if isinstance(item, np.ndarray) and item.shape == (4,):
            return vec4(item)
        return item
        
    def __mul__(self, other):
        if isinstance(other, (int, float, np.float32)):
            return mat4x4(np.array(self) * other)
        elif isinstance(other, vec4):
            m = self
            v = other
            mov0 = vec4(v[0])
            mov1 = vec4(v[1])
            mul0 = vec4(m[0] * mov0)
            mul1 = vec4(m[1] * mov1)
            add0 = vec4(mul0 + mul1)
            mov2 = vec4(v[2])
            mov3 = vec4(v[3])
            mul2 = vec4(m[2] * mov2)
            mul3 = vec4(m[3] * mov3)
            add1 = vec4(mul2 + mul3)
            add2 = vec4(add0 + add1)
            return add2
        elif isinstance(other, mat4x4):
            srcA0 = np.array(self[0])
            srcA1 = np.array(self[1])
            srcA2 = np.array(self[2])
            srcA3 = np.array(self[3])
            
            srcB0 = np.array(other[0])
            srcB1 = np.array(other[1])
            srcB2 = np.array(other[2])
            srcB3 = np.array(other[3])
            
            result = np.identity(4, dtype=np.float32)
            result[0] = srcA0 * srcB0[0] + srcA1 * srcB0[1] + srcA2 * srcB0[2] + srcA3 * srcB0[3]
            result[1] = srcA0 * srcB1[0] + srcA1 * srcB1[1] + srcA2 * srcB1[2] + srcA3 * srcB1[3]
            result[2] = srcA0 * srcB2[0] + srcA1 * srcB2[1] + srcA2 * srcB2[2] + srcA3 * srcB2[3]
            result[3] = srcA0 * srcB3[0] + srcA1 * srcB3[1] + srcA2 * srcB3[2] + srcA3 * srcB3[3]
            
            return mat4x4(result)
        else:
            raise ValueError("Invalid operand")
    
    def __str__(self):
        return f"mat4x4( {self[0][0]}, {self[0][1]}, {self[0][2]}, {self[0][3]} | " + \
            f"{self[1][0]}, {self[1][1]}, {self[1][2]}, {self[1][3]} | " + \
            f"{self[2][0]}, {self[2][1]}, {self[2][2]}, {self[2][3]} | " + \
            f"{self[3][0]}, {self[3][1]}, {self[3][2]}, {self[3][3]} )"
        
    def __repr__(self):
        return self.__str__()

mat3 = mat3x3
mat4 = mat4x4

class quat:
    def __init__(self, *args):
        if len(args) == 0:
            self.quaternion = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32)
        elif len(args) == 1 and isinstance(args[0], np.ndarray):
            self.quaternion = args[0]
        elif len(args) == 1 and isinstance(args[0], quat):
            self.quaternion = np.array(args[0].quaternion, dtype=np.float32)
        elif len(args) == 4:
            self.quaternion = np.array(args, dtype=np.float32)
        else:
            raise ValueError("Invalid arguments")
    
    def __add__(self, other):
        if isinstance(other, quat):
            new_quat = self.quaternion + other.quaternion
            return quat(*new_quat)
        else:
            raise ValueError("Invalid operand")
    
    def __mul__(self, other):
        if isinstance(other, (int, float, np.float32)):
            return quat(self.quaternion * other)
        elif isinstance(other, quat):
            pw, px, py, pz = self.quaternion
            qw, qx, qy, qz = other.quaternion
            w = pw * qw - px * qx - py * qy - pz * qz
            x = pw * qx + px * qw + py * qz - pz * qy
            y = pw * qy + py * qw + pz * qx - px * qz
            z = pw * qz + pz * qw + px * qy - py * qx
            return quat(w, x, y, z)
        else:
            raise ValueError("Invalid operand")
    
    def __rmul__(self, other):
        if isinstance(other, (int, float, np.float32)):
            return quat(self.quaternion * other)
        else:
            raise ValueError("Invalid operand")
    
    def __truediv__(self, other):
        if isinstance(other, (int, float, np.float32)):
            reciprocal = 1.0 / other
            return quat(self.quaternion * reciprocal)
        else:
            raise ValueError("Invalid operand")
    
    def __rtruediv__(self, other):
        raise ValueError("Invalid operation")
    
    def __neg__(self):
        return quat(-self.quaternion[0], -self.quaternion[1], -self.quaternion[2], -self.quaternion[3])
    
    def __getitem__(self, index):
        return self.quaternion[index]
    
    @property
    def w(self):
        return self.quaternion[0]
    
    @property
    def x(self):
        return self.quaternion[1]
    
    @property
    def y(self):
        return self.quaternion[2]
    
    @property
    def z(self):
        return self.quaternion[3]
    
    def __str__(self):
        return f"quat({self.quaternion[0]}, {{{self.quaternion[1]}, {self.quaternion[2]}, {self.quaternion[3]}}})"
        
    def __repr__(self):
        return self.__str__()

def mat3_cast(q):
    result = np.identity(3, dtype=np.float32)
    qxx = q.x * q.x
    qyy = q.y * q.y
    qzz = q.z * q.z
    qxz = q.x * q.z
    qxy = q.x * q.y
    qyz = q.y * q.z
    qwx = q.w * q.x
    qwy = q.w * q.y
    qwz = q.w * q.z
    
    result[0][0] = 1.0 - 2.0 * (qyy +  qzz)
    result[0][1] = 2.0 * (qxy + qwz)
    result[0][2] = 2.0 * (qxz - qwy)

    result[1][0] = 2.0 * (qxy - qwz)
    result[1][1] = 1.0 - 2.0 * (qxx +  qzz)
    result[1][2] = 2.0 * (qyz + qwx)

    result[2][0] = 2.0 * (qxz + qwy)
    result[2][1] = 2.0 * (qyz - qwx)
    result[2][2] = 1.0 - 2.0 * (qxx +  qyy)
    return mat3x3(result)

def mat4_cast(q):
    return mat4x4(mat3_cast(q))

def pi():
    return 3.14159265358979323846264338327950288

def radians(degrees):
    return degrees * 0.01745329251994329576923690768489
    
def acos(rad):
    return np.arccos(rad)
    
def cos(rad):
    return np.cos(rad)

def sin(rad):
    return np.sin(rad)

def tan(rad):
    return np.tan(rad)

def inversesqrt(x):
    return 1.0 / np.sqrt(x)

def dot(a, b):
    if isinstance(a, quat) and isinstance(b, quat):
        tmp = vec4(a.w * b.w, a.x * b.x, a.y * b.y, a.z * b.z)
        return (tmp.x + tmp.y) + (tmp.z + tmp.w)
    elif isinstance(a, (vec3, vec4)) and isinstance(b, (vec3, vec4)):
        tmp = a * b
        return tmp[0] + tmp[1] + tmp[2]
    else:
        raise ValueError("Invalid arguments")

def normalize(v):
    v = vec3(v)
    return v * inversesqrt(dot(v, v))

def length(v):
    return np.sqrt(dot(v, v))

def epsilon():
    return 1.192092896e-07    # smallest such that 1.0+FLT_EPSILON != 1.0

def mix(x, y, a):
    return x * (1.0 - a) + y * a

def slerp(x, y, a):
    z = y
    
    cosTheta = dot(x, y)
    
    # If cosTheta < 0, the interpolation will take the long way around the sphere.
    # To fix this, one quat must be negated.
    if cosTheta < 0.0:
        z = -y
        cosTheta = -cosTheta
    
    # Perform a linear interpolation when cosTheta is close to 1 to avoid side effect of sin(angle) becoming a zero denominator
    if cosTheta > 1.0 - epsilon():
        # Linear interpolation
        return quat(
            mix(x.w, z.w, a),
            mix(x.x, z.x, a),
            mix(x.y, z.y, a),
            mix(x.z, z.z, a))
    else:
        # Essential Mathematics, page 467
        angle = acos(cosTheta)
        return (sin((1.0 - a) * angle) * x + sin(a * angle) * z) / sin(angle)

def inverse(m):
        coef00 = m[2][2] * m[3][3] - m[3][2] * m[2][3]
        coef02 = m[1][2] * m[3][3] - m[3][2] * m[1][3]
        coef03 = m[1][2] * m[2][3] - m[2][2] * m[1][3]

        coef04 = m[2][1] * m[3][3] - m[3][1] * m[2][3]
        coef06 = m[1][1] * m[3][3] - m[3][1] * m[1][3]
        coef07 = m[1][1] * m[2][3] - m[2][1] * m[1][3]

        coef08 = m[2][1] * m[3][2] - m[3][1] * m[2][2]
        coef10 = m[1][1] * m[3][2] - m[3][1] * m[1][2]
        coef11 = m[1][1] * m[2][2] - m[2][1] * m[1][2]

        coef12 = m[2][0] * m[3][3] - m[3][0] * m[2][3]
        coef14 = m[1][0] * m[3][3] - m[3][0] * m[1][3]
        coef15 = m[1][0] * m[2][3] - m[2][0] * m[1][3]

        coef16 = m[2][0] * m[3][2] - m[3][0] * m[2][2]
        coef18 = m[1][0] * m[3][2] - m[3][0] * m[1][2]
        coef19 = m[1][0] * m[2][2] - m[2][0] * m[1][2]

        coef20 = m[2][0] * m[3][1] - m[3][0] * m[2][1]
        coef22 = m[1][0] * m[3][1] - m[3][0] * m[1][1]
        coef23 = m[1][0] * m[2][1] - m[2][0] * m[1][1]

        fac0 = vec4(coef00, coef00, coef02, coef03)
        fac1 = vec4(coef04, coef04, coef06, coef07)
        fac2 = vec4(coef08, coef08, coef10, coef11)
        fac3 = vec4(coef12, coef12, coef14, coef15)
        fac4 = vec4(coef16, coef16, coef18, coef19)
        fac5 = vec4(coef20, coef20, coef22, coef23)

        Vec0 = vec4(m[1][0], m[0][0], m[0][0], m[0][0])
        Vec1 = vec4(m[1][1], m[0][1], m[0][1], m[0][1])
        Vec2 = vec4(m[1][2], m[0][2], m[0][2], m[0][2])
        Vec3 = vec4(m[1][3], m[0][3], m[0][3], m[0][3])

        inv0 = vec4(Vec1 * fac0 - Vec2 * fac1 + Vec3 * fac2)
        inv1 = vec4(Vec0 * fac0 - Vec2 * fac3 + Vec3 * fac4)
        inv2 = vec4(Vec0 * fac1 - Vec1 * fac3 + Vec3 * fac5)
        inv3 = vec4(Vec0 * fac2 - Vec1 * fac4 + Vec2 * fac5)

        signA = vec4(+1, -1, +1, -1)
        signB = vec4(-1, +1, -1, +1)
        Inverse = mat4([inv0 * signA, inv1 * signB, inv2 * signA, inv3 * signB])

        row0 = vec4(Inverse[0][0], Inverse[1][0], Inverse[2][0], Inverse[3][0])

        dot0 = vec4(m[0] * row0)
        dot1 = (dot0.x + dot0.y) + (dot0.z + dot0.w)

        oneOverDeterminant = 1.0 / dot1

        return mat4x4(Inverse * oneOverDeterminant)

def translate(m, v):
    result = np.array(m)
    result[3] = m[0] * v[0] + m[1] * v[1] + m[2] * v[2] + m[3]
    return mat4x4(result)

def rotate(m, angle, v):
    if isinstance(m, quat):
        tmp = v
        
        # Axis of rotation must be normalised
        len = length(tmp)
        if abs(len - 1.0) > 0.001:
            oneOverLen = 1.0 / len
            tmp.x *= oneOverLen
            tmp.y *= oneOverLen
            tmp.z *= oneOverLen
        
        angleRad = angle
        Sin = sin(angleRad * 0.5)
        
        return m * quat(cos(angleRad * 0.5), tmp.x * Sin, tmp.y * Sin, tmp.z * Sin)
    elif isinstance(m, mat4x4):
        a = angle
        c = cos(a)
        s = sin(a)
        
        axis = normalize(v)
        temp = (1.0 - c) * axis
        
        rotate = np.identity(4, dtype=np.float32)
        rotate[0][0] = c + temp[0] * axis[0]
        rotate[0][1] = temp[0] * axis[1] + s * axis[2]
        rotate[0][2] = temp[0] * axis[2] - s * axis[1]
        
        rotate[1][0] = temp[1] * axis[0] - s * axis[2]
        rotate[1][1] = c + temp[1] * axis[1]
        rotate[1][2] = temp[1] * axis[2] + s * axis[0]
        
        rotate[2][0] = temp[2] * axis[0] + s * axis[1]
        rotate[2][1] = temp[2] * axis[1] - s * axis[0]
        rotate[2][2] = c + temp[2] * axis[2]
        
        result = np.identity(4, dtype=np.float32)
        result[0] = m[0] * rotate[0][0] + m[1] * rotate[0][1] + m[2] * rotate[0][2]
        result[1] = m[0] * rotate[1][0] + m[1] * rotate[1][1] + m[2] * rotate[1][2]
        result[2] = m[0] * rotate[2][0] + m[1] * rotate[2][1] + m[2] * rotate[2][2]
        result[3] = m[3]
        return mat4x4(result)
    else:
        raise ValueError("Invalid arguments")

def scale(m, v):
    result = np.identity(4, dtype=np.float32)
    result[0] = m[0] * v[0]
    result[1] = m[1] * v[1]
    result[2] = m[2] * v[2]
    result[3] = m[3]
    return mat4x4(result)

def ortho(left, right, bottom, top, zNear, zFar):
    """
    >>> left = -2.0
    >>> right = 2.0
    >>> bottom = -1.0
    >>> top = 1.0
    >>> nearVal = 0.1
    >>> farVal = 100.0
    >>> ortho(left, right, bottom, top, nearVal, farVal)
    mat4x4( 0.5, 0.0, 0.0, 0.0 | 0.0, 1.0, 0.0, 0.0 | 0.0, 0.0, -0.0200200192630291, 0.0 | -0.0, -0.0, -1.0020020008087158, 1.0 )
    """
    result = np.identity(4, dtype=np.float32)
    result[0][0] = 2 / (right - left)
    result[1][1] = 2 / (top - bottom)
    result[2][2] = - 2 / (zFar - zNear)
    result[3][0] = - (right + left) / (right - left)
    result[3][1] = - (top + bottom) / (top - bottom)
    result[3][2] = - (zFar + zNear) / (zFar - zNear)
    return mat4x4(result)

def perspective(fovy, aspect, zNear, zFar):
    assert(abs(aspect - epsilon()) > 0.0)

    tanHalfFovy = tan(fovy / 2.0)

    result = np.zeros((4, 4), dtype=np.float32)
    result[0][0] = 1.0 / (aspect * tanHalfFovy)
    result[1][1] = 1.0 / (tanHalfFovy)
    result[2][2] = - (zFar + zNear) / (zFar - zNear)
    result[2][3] = - 1.0
    result[3][2] = - (2.0 * zFar * zNear) / (zFar - zNear)
    return mat4x4(result)

def lookAt(eye, center, up):
    """
    >>> eye = vec3(0.0, 0.0, 5.0)
    >>> center = vec3(0.0, 0.0, 0.0)
    >>> up = vec3(0.0, 1.0, 0.0)
    >>> lookAt(eye, center, up)
    mat4x4( 1.0, 0.0, -0.0, 0.0 | -0.0, 1.0, -0.0, 0.0 | 0.0, 0.0, 1.0, 0.0 | -0.0, -0.0, -5.0, 1.0 )
    """
    eye = np.array(eye)
    center = np.array(center)
    up = np.array(up)

    f_ = center - eye
    f = f_ / np.linalg.norm(f_)
    s_ = np.cross(f, up)
    s = s_ / np.linalg.norm(s_)
    u = np.cross(s, f)

    result = np.identity(4, dtype=np.float32)
    result[0][0] = s[0]
    result[1][0] = s[1]
    result[2][0] = s[2]
    result[0][1] = u[0]
    result[1][1] = u[1]
    result[2][1] = u[2]
    result[0][2] = -f[0]
    result[1][2] = -f[1]
    result[2][2] = -f[2]
    result[3][0] = -np.dot(s, eye)
    result[3][1] = -np.dot(u, eye)
    result[3][2] =  np.dot(f, eye)
    return mat4x4(result)

def glm_test():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    glm_test()
