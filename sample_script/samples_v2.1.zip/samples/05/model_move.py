from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import gl_util
import my_glm as glm

vert_pos = np.array([
    [-0.25, -0.25, 0.0],
    [0.25, -0.25, 0.0],
    [0.25, 0.25, 0.0],
    [-0.25, 0.25, 0.0]], dtype=np.float32)
program = None
pos_vbo = None
x_pos = 0.0

vertex_shader_src="""
#version 400 core

layout(location = 0) in vec3 position;
uniform mat4 MVP;

void main(void) {
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = vec4(1.0);
}
""".strip()

def init(window, width, height):
    global program, pos_vbo
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_vbo = gl_util.create_vbo(vert_pos)

def update(window, width, height):
    global x_pos
    # X 座標値を更新
    elapsed_seconds = glfw.get_time()
    x_pos = elapsed_seconds * 0.5
    T = glm.translate(glm.mat4(1.0), glm.vec3(x_pos, 0.0, 0.0))
    M = T
    MVP = np.array(M, dtype=np.float32)
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUseProgram(program)
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    glUseProgram(0)

def draw():
    glUseProgram(program)
    glEnableVertexAttribArray(0)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
    num_vertex = vert_pos.size // 3
    glDrawArrays(GL_LINE_LOOP, 0, num_vertex)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glUseProgram(0)

SCREEN_WIDTH = 480
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
