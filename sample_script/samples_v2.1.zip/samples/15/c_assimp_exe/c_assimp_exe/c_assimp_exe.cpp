﻿// c_assimp_exe.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include "../c_assimp/c_assimp.h"
#include <stdio.h>

int main()
{
	c_import_file("C:\\Assimp_DL\\c_assimp_exe\\x64\\Debug\\triangles.obj");
	int num_mesh = c_get_num_meshes();
	printf("num_mesh=%d\n", num_mesh);

	return 0;
}