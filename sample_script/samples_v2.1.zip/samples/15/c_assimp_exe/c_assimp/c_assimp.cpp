// c_assimp.cpp : Defines the exported functions for the DLL application.
//

#include "c_assimp.h"
#include <assimp/cimport.h>
#include <assimp/postprocess.h>
#include <assimp/scene.h>
#include <vector>
#include <map>
#include <string>

static bool st_verbose = false;
static const aiScene* st_scene = NULL;
static float* st_points = NULL;		// array of vertex points
static int* st_faces = NULL;		// array of face indexs
static float* st_normals = NULL;	// array of vertex normals
static float* st_texcoords = NULL;	// array of texture coordinates
static float st_diffuse_color[4];	// array of diffuse colors
static float st_bone_offset_matrix[16] = { 0.0f };
static float st_transform_matrix[16] = { 0.0f };
std::map<std::string, aiNode*> st_nodeMap;

void c_set_verbose(bool flag)
{
	st_verbose = flag;
	printf("verbose: %s\n", flag ? "True" : "False");
}

bool c_get_skeleton_root_node_name(char* name)
{
	aiNode* assimp_node = st_scene->mRootNode;
	if (assimp_node != NULL) {
		strcpy_s(name, 64, assimp_node->mName.C_Str());
		return true;
	}
	return false;
}

int c_get_skeleton_node_num_children(char* name)
{
	int num_children = 0;
	std::string nodeName(name);
	if (st_nodeMap.count(nodeName) != 0) {
		auto assimp_node = st_nodeMap[nodeName];
		num_children = assimp_node->mNumChildren;
	}
	return num_children;
}

void c_get_skeleton_child_node_name(char* name, int child_idx, char* child_name)
{
	std::string nodeName(name);
	if (st_nodeMap.count(nodeName) != 0) {
		auto assimp_node = st_nodeMap[nodeName];
		auto child_node = assimp_node->mChildren[child_idx];
		strcpy_s(child_name, 64, child_node->mName.C_Str());
	}
}

void c_get_skeleton_transform_matrix(char* name, float** transform_matrix)
{
	for (int i = 0; i < 16; i++) {
		st_transform_matrix[i] = 0.0f;
	}
	std::string nodeName(name);
	if (st_nodeMap.count(nodeName) != 0) {
		auto assimp_node = st_nodeMap[nodeName];
		auto matrix = assimp_node->mTransformation;
		// get by column order
		auto transformMatrix = assimp_node->mTransformation;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				st_transform_matrix[i * 4 + j] = transformMatrix[j][i];
			}
		}
	}
	*transform_matrix = st_transform_matrix;
}

int c_get_num_node_mesh(char* node_name)
{
	auto assimp_node = st_nodeMap[node_name];
	int numMesh = assimp_node->mNumMeshes;
	return numMesh;
}

int c_get_node_mesh_index(char* node_name, int idx)
{
	auto assimp_node = st_nodeMap[node_name];
	int mesh_idx = assimp_node->mMeshes[idx];
	return mesh_idx;
}

void import_skeleton_node(aiNode *assimp_node)
{
	std::string name(assimp_node->mName.C_Str());
	st_nodeMap[name] = assimp_node;

	for (int i = 0; i < (int)assimp_node->mNumChildren; i++) {
		import_skeleton_node(assimp_node->mChildren[i]);
	}
}

void c_import_file(const char* file_name)
{
	st_scene = aiImportFile(file_name, aiProcess_Triangulate | aiProcess_RemoveRedundantMaterials);
	if (!st_scene) {
		fprintf(stderr, "ERROR: reading mesh %s\n", file_name);
		return;
	}
}

void c_import_skeleton_node()
{
	// get the skeleton hierarchy from a separate AssImp data structure
	aiNode* assimp_node = st_scene->mRootNode;
	import_skeleton_node(assimp_node);
}

void c_release_import()
{
	if (st_scene != NULL) {
		aiReleaseImport(st_scene);
		st_scene = NULL;
	}
	st_nodeMap.clear();
}

int c_get_num_meshes()
{
	if (st_scene) {
		return st_scene->mNumMeshes;
	}
	return 0;
}

int c_get_num_vertices(int mesh_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			return mesh->mNumVertices;
		}
	}
	return 0;
}

int c_get_num_faces(int mesh_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			return mesh->mNumFaces;
		}
	}
	return 0;
}

int c_get_has_positions(int mesh_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			return mesh->HasPositions() ? 1 : 0;
		}
	}
	return 0;
}

int c_get_has_normals(int mesh_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			return mesh->HasNormals() ? 1 : 0;
		}
	}
	return 0;
}

int c_get_has_textureCoords(int mesh_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			return mesh->HasTextureCoords(0) ? 1 : 0;
		}
	}
	return 0;
}

void c_get_positions(int mesh_idx, float** positions)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			if (st_points) {
				delete[] st_points;
				st_points = NULL;
			}
			int point_count = mesh->mNumVertices;
			if (point_count == 0) return;
			st_points = new float[point_count * 3];
			for (int i = 0; i < point_count; i++) {
				const aiVector3D* vp = &(mesh->mVertices[i]);
				st_points[i * 3] = (float)vp->x;
				st_points[i * 3 + 1] = (float)vp->y;
				st_points[i * 3 + 2] = (float)vp->z;
			}
			*positions = st_points;
		}
	}
}

void c_get_faces(int mesh_idx, int** faces)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			if (st_faces) {
				delete[] st_faces;
				st_faces = NULL;
			}
			int face_count = (int)mesh->mNumFaces;
			if (face_count == 0) return;
			st_faces = new int[face_count * 3];
			for (int i = 0; i < face_count; i++) {
				for (int j = 0; j < 3; j++) {
					st_faces[i * 3 + j] = (int)mesh->mFaces[i].mIndices[j];
				}
			}
			*faces = st_faces;
		}
	}
}

void c_get_normals(int mesh_idx, float** normals)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			if (st_normals) {
				delete[] st_normals;
				st_normals = NULL;
			}
			int point_count = mesh->mNumVertices;
			if (point_count == 0) return;
			st_normals = new float[point_count * 3];
			for (int i = 0; i < point_count; i++) {
				const aiVector3D* vn = &(mesh->mNormals[i]);
				st_normals[i * 3] = (float)vn->x;
				st_normals[i * 3 + 1] = (float)vn->y;
				st_normals[i * 3 + 2] = (float)vn->z;
			}
			*normals = st_normals;
		}
	}
}

void c_get_textureCoords(int mesh_idx, float** texCoords)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			if (st_texcoords) {
				delete[] st_texcoords;
				st_texcoords = NULL;
			}
			int point_count = mesh->mNumVertices;
			if (point_count == 0) return;
			st_texcoords = new float[point_count * 2];
			for (int i = 0; i < point_count; i++) {
				const aiVector3D* vt = &(mesh->mTextureCoords[0][i]);
				st_texcoords[i * 2] = (float)vt->x;
				st_texcoords[i * 2 + 1] = (float)vt->y;
			}
			*texCoords = st_texcoords;
		}
	}
}

bool c_get_texture_file_name(int mesh_idx, char* file_name)
{
	file_name[0] = '\0';
	if (st_scene && st_scene->HasMaterials()) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			auto pMat = st_scene->mMaterials[mesh->mMaterialIndex];
			aiString path;
			if (aiReturn_SUCCESS == aiGetMaterialTexture(pMat, aiTextureType_DIFFUSE, 0, &path))
			{
				bool has_folder = false;
				int idx = 0;
				size_t size = strlen(path.data);
				for (auto i = 0; i < size; i++) {	// remove folder path
					if (path.data[i] == '/' || path.data[i] == '\\') {
						idx = i;
						has_folder = true;
					}
				}
				if (has_folder) {
					idx++;
				}
				strcpy_s(file_name, 1024, path.data + idx);
				return true;
			}
		}
	}
	return false;
}

bool c_get_diffuse_color(int mesh_idx, float** color)
{
	if (st_scene && st_scene->HasMaterials()) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh) {
			auto pMat = st_scene->mMaterials[mesh->mMaterialIndex];
			aiColor4D aiColor(1.0f);
			if (AI_SUCCESS == aiGetMaterialColor(pMat, AI_MATKEY_COLOR_DIFFUSE,
				(aiColor4D*)&aiColor)) {
				for (int i = 0; i < 4; i++) {
					st_diffuse_color[i] = aiColor[i];
				}
				*color = st_diffuse_color;
				return true;
			}
		}
	}
	return false;
}

int c_get_num_bones(int mesh_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh && mesh->HasBones()) {
			return mesh->mNumBones;
		}
	}
	return 0;
}

void c_get_bone_name(int mesh_idx, int bone_idx, char* bone_name)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh && mesh->HasBones()) {
			const aiBone* bone = mesh->mBones[bone_idx];
			strcpy_s(bone_name, 1024, bone->mName.data);
		}
	}
}

void c_get_bone_offset_matrix(int mesh_idx, int bone_idx, float** offset_matrix)
{
	for (int i = 0; i < 16; i++) {
		st_bone_offset_matrix[i] = 0.0f;
	}
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh && mesh->HasBones()) {
			const aiBone* bone = mesh->mBones[bone_idx];
			auto mat = bone->mOffsetMatrix;
			// get by column order
			for (int i = 0; i < 4; i++) {
				for (int j = 0; j < 4; j++) {
					st_bone_offset_matrix[j + i*4] = mat[j][i];
				}
			}
		}
	}
	*offset_matrix = st_bone_offset_matrix;
}

int c_get_bone_num_weights(int mesh_idx, int bone_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh && mesh->HasBones()) {
			const aiBone* bone = mesh->mBones[bone_idx];
			return (int)bone->mNumWeights;
		}
	}
	return 0;
}

int c_get_bone_vertex_id(int mesh_idx, int bone_idx, int weight_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh && mesh->HasBones()) {
			const aiBone* bone = mesh->mBones[bone_idx];
			aiVertexWeight weight = bone->mWeights[weight_idx];
			return (int)weight.mVertexId;
		}
	}
	return -1;
}

float c_get_bone_weight(int mesh_idx, int bone_idx, int weight_idx)
{
	if (st_scene) {
		const aiMesh* mesh = st_scene->mMeshes[mesh_idx];
		if (mesh && mesh->HasBones()) {
			const aiBone* bone = mesh->mBones[bone_idx];
			aiVertexWeight weight = bone->mWeights[weight_idx];
			return weight.mWeight;
		}
	}
	return 0.0;
}

int c_get_num_animations()
{
	if (st_scene) {
		return (int)st_scene->mNumAnimations;
	}
	return 0;
}

void c_get_anim_name(int anim_idx, char* anim_name)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		strcpy_s(anim_name, 64, anim->mName.C_Str());
	}
}

double c_get_anim_duration(int anim_idx)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		return anim->mDuration;
	}
	return 0.0;
}

double c_get_anim_ticksPerSecond(int anim_idx)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		return anim->mTicksPerSecond;
	}
	return 0.0;
}

int c_get_anim_num_channels(int anim_idx)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		return anim->mNumChannels;
	}
	return 0;
}

void c_get_anim_channel_node_name(int anim_idx, int chan_idx, char* node_name)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		aiNodeAnim* chan = anim->mChannels[chan_idx];
		strcpy_s(node_name, 64, chan->mNodeName.C_Str());
	}
}

int c_get_anim_num_position_keys(int anim_idx, int chan_idx)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		aiNodeAnim* chan = anim->mChannels[chan_idx];
		return (int)chan->mNumPositionKeys;
	}
	return 0;
}

int c_get_anim_num_rotation_keys(int anim_idx, int chan_idx)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		aiNodeAnim* chan = anim->mChannels[chan_idx];
		return (int)chan->mNumRotationKeys;
	}
	return 0;
}

int c_get_anim_num_scaling_keys(int anim_idx, int chan_idx)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		aiNodeAnim* chan = anim->mChannels[chan_idx];
		return (int)chan->mNumScalingKeys;
	}
	return 0;
}

void c_get_anim_position_keys(int anim_idx, int chan_idx, int key_idx,
	float* x, float* y, float* z, double* time)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		aiNodeAnim* chan = anim->mChannels[chan_idx];
		aiVectorKey key = chan->mPositionKeys[key_idx];
		*x = key.mValue.x;
		*y = key.mValue.y;
		*z = key.mValue.z;
		*time = key.mTime;
	}
}

void c_get_anim_rotation_keys(int anim_idx, int chan_idx, int key_idx,
	float* w, float* x, float* y, float* z, double* time)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		aiNodeAnim* chan = anim->mChannels[chan_idx];
		aiQuatKey key = chan->mRotationKeys[key_idx];
		*w = key.mValue.w;
		*x = key.mValue.x;
		*y = key.mValue.y;
		*z = key.mValue.z;
		*time = key.mTime;
	}
}

void c_get_anim_scaling_keys(int anim_idx, int chan_idx, int key_idx,
	float* x, float* y, float* z, double* time)
{
	if (st_scene) {
		aiAnimation* anim = st_scene->mAnimations[anim_idx];
		aiNodeAnim* chan = anim->mChannels[chan_idx];
		aiVectorKey key = chan->mScalingKeys[key_idx];
		*x = key.mValue.x;
		*y = key.mValue.y;
		*z = key.mValue.z;
		*time = key.mTime;
	}
}

