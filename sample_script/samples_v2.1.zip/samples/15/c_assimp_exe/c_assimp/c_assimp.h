#pragma once

#define DllExport __declspec(dllexport)

#ifdef __cplusplus
extern "C" {
#endif

DllExport void c_import_file(const char* file_name);
DllExport void c_import_skeleton_node();
DllExport void c_release_import();
DllExport void c_set_verbose(bool flag);
// mesh
DllExport int c_get_num_meshes();
DllExport int c_get_num_vertices(int mesh_idx);
DllExport int c_get_num_faces(int mesh_idx);
DllExport int c_get_has_positions(int mesh_idx);
DllExport int c_get_has_normals(int mesh_idx);
DllExport int c_get_has_textureCoords(int mesh_idx);
DllExport void c_get_positions(int mesh_idx, float** positions);
DllExport void c_get_faces(int mesh_idx, int** faces);
DllExport void c_get_normals(int mesh_idx, float** normals);
DllExport void c_get_textureCoords(int mesh_idx, float** texCoords);
DllExport bool c_get_texture_file_name(int mesh_idx, char* file_name);
DllExport bool c_get_diffuse_color(int mesh_idx, float** color);
// bone
DllExport int c_get_num_bones(int mesh_idx);
DllExport void c_get_bone_name(int mesh_idx, int bone_idx, char* bone_name);
DllExport void c_get_bone_offset_matrix(int mesh_idx, int bone_idx, float** offset_matrix);
DllExport int c_get_bone_num_weights(int mesh_idx, int bone_idx);
DllExport int c_get_bone_vertex_id(int mesh_idx, int bone_idx, int weight_idx);
DllExport float c_get_bone_weight(int mesh_idx, int bone_idx, int weight_idx);
// skeleton
DllExport bool c_get_skeleton_root_node_name(char* name);
DllExport int c_get_skeleton_node_num_children(char* name);
DllExport void c_get_skeleton_child_node_name(char* name, int child_idx, char* child_name);
DllExport void c_get_skeleton_transform_matrix(char* name, float** transform_matrix);
DllExport int c_get_num_node_mesh(char* node_name);
DllExport int c_get_node_mesh_index(char* node_name, int idx);
// animation
DllExport int c_get_num_animations();
DllExport void c_get_anim_name(int anim_idx, char* anim_name);
DllExport double c_get_anim_duration(int anim_idx);
DllExport double c_get_anim_ticksPerSecond(int anim_idx);
DllExport int c_get_anim_num_channels(int anim_idx);
DllExport void c_get_anim_channel_node_name(int anim_idx, int chan_idx, char* node_name);
DllExport int c_get_anim_num_position_keys(int anim_idx, int chan_idx);
DllExport int c_get_anim_num_rotation_keys(int anim_idx, int chan_idx);
DllExport int c_get_anim_num_scaling_keys(int anim_idx, int chan_idx);
DllExport void c_get_anim_position_keys(int anim_idx, int chan_idx, int key_idx,
	float* x, float* y, float* z, double* time);
DllExport void c_get_anim_rotation_keys(int anim_idx, int chan_idx, int key_idx,
	float* w, float* x, float* y, float* z, double* time);
DllExport void c_get_anim_scaling_keys(int anim_idx, int chan_idx, int key_idx,
	float* x, float* y, float* z, double* time);

#ifdef __cplusplus
}
#endif
