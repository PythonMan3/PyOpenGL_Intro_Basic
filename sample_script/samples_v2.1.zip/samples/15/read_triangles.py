from c_assimp import *

import_file("data/triangles.obj")
num_mesh = get_num_meshes()
print("num_mesh={}".format(num_mesh))
num_mesh = get_num_meshes()
for mesh_idx in range(num_mesh):
    num_vertex = get_num_vertices(mesh_idx)
    print("num_vertex={}".format(num_vertex))
    if get_has_positions(mesh_idx):
        vertexs = get_positions(mesh_idx)
        num_face = get_num_faces(mesh_idx)
        faces = get_faces(mesh_idx)
        print("vertex={}".format(vertexs))
        print("num_face={}".format(num_face))
        print("faces={}".format(faces))
