from ctypes import *
import pathlib
from bounding_box import BoundBox
import my_glm as glm

# Interface for Assimp
dll = cdll.LoadLibrary(str(pathlib.Path('c_assimp.dll').absolute()))

def import_file(dae_file):
    dae_file_b = dae_file.encode('utf-8')
    dll.c_import_file(dae_file_b)

def import_skeleton_node():
    dll.c_import_skeleton_node()

def release_import():
    dll.c_release_import()

def c_set_verbose(flag):
    dll.c_set_verbose.argtypes = [c_bool]
    dll.c_set_verbose.restype = None
    dll.c_set_verbose(flag)

# mesh
def get_num_meshes():
    return dll.c_get_num_meshes()

def get_num_vertices(mesh_idx):
    return dll.c_get_num_vertices(mesh_idx)

def get_num_faces(mesh_idx):
    return dll.c_get_num_faces(mesh_idx)

def get_has_positions(mesh_idx):
    return dll.c_get_has_positions(mesh_idx)

def get_has_normals(mesh_idx):
    return dll.c_get_has_normals(mesh_idx)

def get_has_textureCoords(mesh_idx):
    return dll.c_get_has_textureCoords(mesh_idx)

def get_positions(mesh_idx):
    num_vertex = get_num_vertices(mesh_idx)
    dll.c_get_positions.argtypes = [c_int, POINTER(POINTER(c_float))]
    dll.c_get_positions.restype = None
    vertex = POINTER(c_float)()
    dll.c_get_positions(mesh_idx, byref(vertex))
    return vertex[:num_vertex*3]

def get_faces(mesh_idx):
    num_face = get_num_faces(mesh_idx)
    dll.c_get_faces.argtypes = [c_int, POINTER(POINTER(c_int))]
    dll.c_get_faces.restype = None
    faces = POINTER(c_int)()
    dll.c_get_faces(mesh_idx, byref(faces))
    return faces[:num_face*3]

def get_normals(mesh_idx):
    num_vertex = get_num_vertices(mesh_idx)
    dll.c_get_normals.argtypes = [c_int, POINTER(POINTER(c_float))]
    dll.c_get_normals.restype = None
    normal = POINTER(c_float)()
    dll.c_get_normals(mesh_idx, byref(normal))
    return normal[:num_vertex*3]

def get_textureCoords(mesh_idx):
    num_vertex = get_num_vertices(mesh_idx)
    dll.c_get_textureCoords.argtypes = [c_int, POINTER(POINTER(c_float))]
    dll.c_get_textureCoords.restype = None
    texCoord = POINTER(c_float)()
    dll.c_get_textureCoords(mesh_idx, byref(texCoord))
    tex_crds = []
    for i in range(num_vertex):
        tex_crds.append(texCoord[i*2])
        tex_crds.append(1.0 - texCoord[i*2+1])
    return tex_crds

def get_texture_file_name(mesh_idx):
    u_str = " "*1024
    enc_str = u_str.encode('utf-8')
    fname = create_string_buffer(enc_str)
    dll.c_get_texture_file_name.argtypes = [c_int, c_char_p]
    dll.c_get_texture_file_name.restype = c_bool
    tex_file_name = ""
    if dll.c_get_texture_file_name(mesh_idx, fname):
        tex_file_name = fname.value
        tex_file_name = tex_file_name.decode('utf-8').strip()
    return tex_file_name

def get_diffuse_color(mesh_idx):
    dll.c_get_diffuse_color.argtypes = [c_int, POINTER(POINTER(c_float))]
    dll.c_get_diffuse_color.restype = c_bool
    color = POINTER(c_float)()
    diffuse_color = [1.0] * 4
    if dll.c_get_diffuse_color(mesh_idx, byref(color)):
        diffuse_color = color[:4]
    return diffuse_color

# bone
def get_num_bones(mesh_idx):
    return dll.c_get_num_bones(mesh_idx)

def get_bone_name(mesh_idx, bone_idx):
    u_str = " "*1024
    enc_str = u_str.encode('utf-8')
    name = create_string_buffer(enc_str)
    dll.c_get_bone_name.argtypes = [c_int, c_int, c_char_p]
    dll.c_get_bone_name.restype = None
    dll.c_get_bone_name(mesh_idx, bone_idx, name)
    bone_name = name.value
    bone_name = bone_name.decode('utf-8').strip()
    return bone_name

def get_bone_offset_matrix(mesh_idx, bone_idx):
    dll.c_get_bone_offset_matrix.argtypes = [c_int, c_int, POINTER(POINTER(c_float))]
    dll.c_get_bone_offset_matrix.restype = None
    matrix = POINTER(c_float)()
    dll.c_get_bone_offset_matrix(mesh_idx, bone_idx, byref(matrix))
    matrix = matrix[:16]
    return matrix

def get_bone_num_weights(mesh_idx, bone_idx):
    num_weights = dll.c_get_bone_num_weights(mesh_idx, bone_idx)
    return num_weights

def get_bone_vertex_id(mesh_idx, bone_idx, weight_idx):
    return dll.c_get_bone_vertex_id(mesh_idx, bone_idx, weight_idx)

def get_bone_weight(mesh_idx, bone_idx, weight_idx):
    dll.c_get_bone_weight.argtypes = [c_int, c_int, c_int]
    dll.c_get_bone_weight.restype = c_float
    return dll.c_get_bone_weight(mesh_idx, bone_idx, weight_idx)

# skeleton
def get_skeleton_root_node_name():
    u_str = " "*64
    enc_str = u_str.encode('utf-8')
    name_c = create_string_buffer(enc_str)
    dll.c_get_skeleton_root_node_name.argtypes = [c_char_p]
    dll.c_get_skeleton_root_node_name.restype = c_bool
    name = ""
    if dll.c_get_skeleton_root_node_name(name_c):
        name_b = name_c.value
        name = name_b.decode('utf-8').strip()
    return name

def get_skeleton_node_num_children(name):
    name_b = name.encode('utf-8')
    return dll.c_get_skeleton_node_num_children(name_b)

def get_skeleton_child_node_name(name, child_idx):
    name_b = name.encode('utf-8')
    u_str = " "*64
    enc_str = u_str.encode('utf-8')
    child_name_c = create_string_buffer(enc_str)
    dll.c_get_skeleton_child_node_name.argtypes = [c_char_p, c_int, c_char_p]
    dll.c_get_skeleton_child_node_name.restype = None
    dll.c_get_skeleton_child_node_name(name_b, child_idx, child_name_c)
    child_name_b = child_name_c.value
    child_name = child_name_b.decode('utf-8').strip()
    return child_name

def get_skeleton_transform_matrix(name):
    name_b = name.encode('utf-8')
    dll.c_get_skeleton_transform_matrix.argtypes = [c_char_p, POINTER(POINTER(c_float))]
    dll.c_get_skeleton_transform_matrix.restype = None
    matrix = POINTER(c_float)()
    dll.c_get_skeleton_transform_matrix(name_b, byref(matrix))
    matrix = matrix[:16]
    return matrix

def get_num_node_mesh(node_name):
    name_b = node_name.encode('utf-8')
    return dll.c_get_num_node_mesh(name_b)

def get_node_mesh_index(node_name, idx):
    name_b = node_name.encode('utf-8')
    return dll.c_get_node_mesh_index(name_b, idx)

# animation
def get_num_animations():
   num_anim = dll.c_get_num_animations()
   return num_anim

def get_anim_name(anim_idx):
    u_str = " "*1024
    enc_str = u_str.encode('utf-8')
    anim_name_c = create_string_buffer(enc_str)
    dll.c_get_anim_name.argtypes = [c_int, c_char_p]
    dll.c_get_anim_name.restype = None
    dll.c_get_anim_name(anim_idx, anim_name_c)
    anim_name_b = anim_name_c.value
    anim_name = anim_name_b.decode('utf-8').strip()
    return anim_name

def get_anim_duration(anim_idx):
    dll.c_get_anim_duration.argtypes = [c_int]
    dll.c_get_anim_duration.restype = c_double
    return dll.c_get_anim_duration(anim_idx)

def get_anim_ticks_per_second(anim_idx):
    dll.c_get_anim_ticksPerSecond.argtypes = [c_int]
    dll.c_get_anim_ticksPerSecond.restype = c_double
    return dll.c_get_anim_ticksPerSecond(anim_idx)

def get_anim_num_channels(anim_idx):
    num_chan = dll.c_get_anim_num_channels(anim_idx)
    return num_chan

def get_anim_channel_node_name(anim_idx, chan_idx):
    u_str = " "*64
    enc_str = u_str.encode('utf-8')
    node_name_c = create_string_buffer(enc_str)
    dll.c_get_anim_channel_node_name.argtypes = [c_int, c_int, c_char_p]
    dll.c_get_anim_channel_node_name.restype = None
    dll.c_get_anim_channel_node_name(anim_idx, chan_idx, node_name_c)
    node_name_b = node_name_c.value
    node_name = node_name_b.decode('utf-8').strip()
    return node_name

def get_anim_num_position_keys(anim_idx, chan_idx):
    num_pos_key = dll.c_get_anim_num_position_keys(anim_idx, chan_idx)
    return num_pos_key

def get_anim_num_rotation_keys(anim_idx, chan_idx):
    num_pos_key = dll.c_get_anim_num_rotation_keys(anim_idx, chan_idx)
    return num_pos_key

def get_anim_num_scaling_keys(anim_idx, chan_idx):
    num_pos_key = dll.c_get_anim_num_scaling_keys(anim_idx, chan_idx)
    return num_pos_key

def get_anim_position_keys(anim_idx, chan_idx, key_idx):
    dll.c_get_anim_position_keys.argtypes = [c_int, c_int, c_int,
        POINTER(c_float), POINTER(c_float), POINTER(c_float), POINTER(c_double)]
    x = c_float()
    y = c_float()
    z = c_float()
    time = c_double()
    dll.c_get_anim_position_keys(anim_idx, chan_idx, key_idx, byref(x), byref(y), byref(z), byref(time))
    return [x.value, y.value, z.value, time.value]

def get_anim_rotation_keys(anim_idx, chan_idx, key_idx):
    dll.c_get_anim_rotation_keys.argtypes = [c_int, c_int, c_int,
        POINTER(c_float), POINTER(c_float), POINTER(c_float), POINTER(c_float), POINTER(c_double)]
    w = c_float()
    x = c_float()
    y = c_float()
    z = c_float()
    time = c_double()
    dll.c_get_anim_rotation_keys(anim_idx, chan_idx, key_idx, byref(w), byref(x), byref(y), byref(z), byref(time))
    return [w.value, x.value, y.value, z.value, time.value]

def get_anim_scaling_keys(anim_idx, chan_idx, key_idx):
    dll.c_get_anim_scaling_keys.argtypes = [c_int, c_int, c_int,
        POINTER(c_float), POINTER(c_float), POINTER(c_float), POINTER(c_double)]
    x = c_float()
    y = c_float()
    z = c_float()
    time = c_double()
    dll.c_get_anim_scaling_keys(anim_idx, chan_idx, key_idx, byref(x), byref(y), byref(z), byref(time))
    return [x.value, y.value, z.value, time.value]

def add_node(parentNode, nodes):
    num_child = get_skeleton_node_num_children(parentNode.name)
    for i in range(num_child):
        child_name = get_skeleton_child_node_name(parentNode.name, i)
        node = Node(child_name)
        parentNode.children.append(node)
        node.transform_matrix = glm.mat4(*get_skeleton_transform_matrix(child_name))
        num_mesh = get_num_node_mesh(child_name)
        for j in range(num_mesh):
            mesh_idx = get_node_mesh_index(child_name, j)
            node.mesh_idxs.append(mesh_idx)
        node.index = len(nodes)
        nodes.append(node)
        add_node(node, nodes)
        
# Imported Data
class Model:
    def __init__(self):
        self.bound_box = BoundBox()
        self.model_file = ""
        self.materials = []
        self.nodes = []
        
    def import_file(self, file_name):
        import_file(file_name)
        self.model_file = file_name
        self.read_mesh()
        self.read_tree_node()
        self.calc_node_transform()  # nodeの位置をメッシュに反映させるため
        release_import()
        
    def read_tree_node(self):
        import_skeleton_node()
        root_name = get_skeleton_root_node_name()
        node = Node(root_name)
        node.transform_matrix = glm.mat4(*get_skeleton_transform_matrix(root_name))
        num_mesh = get_num_node_mesh(root_name)
        for i in range(num_mesh):
            mesh_idx = get_node_mesh_index(root_name, i)
            node.mesh_idxs.append(mesh_idx)
        node.index = len(self.nodes)
        self.nodes.append(node)
        add_node(node, self.nodes)
        
    def set_child_trans(self, node):
        for child_node in node.children:
            child_node.combined_matrix = node.combined_matrix * child_node.transform_matrix
            for mesh_idx in child_node.mesh_idxs:
                mat = self.materials[mesh_idx]
                mat.transform_matrix = child_node.combined_matrix
                self.update_bound_box(mesh_idx, mat.transform_matrix)
            self.set_child_trans(child_node)
            
    def calc_node_transform(self):
        self.bound_box.reset()
        root_node = self.nodes[0]
        root_node.combined_matrix = root_node.transform_matrix
        for mesh_idx in root_node.mesh_idxs:
            mat = self.materials[mesh_idx]
            mat.transform_matrix = root_node.combined_matrix
            self.update_bound_box(mesh_idx, mat.transform_matrix)
        self.set_child_trans(root_node)
        
    def update_bound_box(self, mesh_idx, transform_matrix):
        num_vertex = get_num_vertices(mesh_idx)
        vertexs = get_positions(mesh_idx)
        mesh_bound_box = BoundBox()
        for i in range(num_vertex):
            x = vertexs[i * 3]
            y = vertexs[i * 3 + 1]
            z = vertexs[i * 3 + 2]
            mesh_bound_box.add_point([x, y, z])
        max_min = mesh_bound_box.get_range()
        max_pos, min_pos = max_min[:3], max_min[3:]
        max_pos = list(transform_matrix * glm.vec4(glm.vec3(max_pos), 1.0))[:3]
        min_pos = list(transform_matrix * glm.vec4(glm.vec3(min_pos), 1.0))[:3]
        self.bound_box.add_point(max_pos)
        self.bound_box.add_point(min_pos)
        
    def read_mesh(self):
        num_mesh = get_num_meshes()
        for mesh_idx in range(num_mesh):
            mat = Material()
            self.materials.append(mat)
            # position and face
            if get_has_positions(mesh_idx):
                mat.num_vertex = get_num_vertices(mesh_idx)
                mat.vertexs = get_positions(mesh_idx)
                mat.num_face = get_num_faces(mesh_idx)
                mat.faces = get_faces(mesh_idx)
                mat.has_position = True
            # normal
            if get_has_normals(mesh_idx):
                mat.normals = get_normals(mesh_idx)
                mat.has_normal = True
            # texture coords
            if get_has_textureCoords(mesh_idx):
                mat.uvs = get_textureCoords(mesh_idx)
                mat.has_uv = True
            # texture
            tex_file_name = get_texture_file_name(mesh_idx)
            if tex_file_name:
                folder_p = pathlib.Path(self.model_file).absolute().parent
                tex_p = pathlib.Path(tex_file_name)
                path = folder_p.joinpath(tex_p)
                if path.exists():
                    tex_file_name = str(path)
                    mat.texture_file = tex_file_name
            # diffuse color
            mat.diffuse_color = get_diffuse_color(mesh_idx)

class Node:
    def __init__(self, name):
        self.name = name
        self.children = []
        self.mesh_idxs = []
        self.index = -1
        self.transform_matrix = glm.mat4(0.0)
        self.combined_matrix = glm.mat4()

class Material:
    def __init__(self):
        self.has_position = False
        self.has_normal = False
        self.has_uv = False
        self.num_vertex = 0
        self.vertexs = []
        self.num_face = 0
        self.faces = []
        self.normals = []
        self.uvs = []
        self.texture_file = ""
        self.vao = None
        self.vbo_vertex = None
        self.vbo_normal = None
        self.vbo_tex_coord = None
        self.ibo_faces = None
        self.texture = None
        self.diffuse_color = [1.0] * 4

def process_node(node_name):
    num_child = get_skeleton_node_num_children(node_name)
    for i in range(num_child):
        child_name = get_skeleton_child_node_name(node_name, i)
        process_node(child_name)
        num_mesh = get_num_node_mesh(child_name)
        for j in range(num_mesh):
            mesh_idx = get_node_mesh_index(child_name, j)
            print(child_name, mesh_idx)##

if __name__ == "__main__":
    #model = Model()
    #model.import_file("avator_2.glb")
    import_file("avator_2.glb")
    import_skeleton_node()
    root_name = get_skeleton_root_node_name()
    process_node(root_name)
    
    num_mesh = get_num_meshes()
    print(f"num_mesh={num_mesh}")
    for mesh_idx in range(num_mesh):
        print(mesh_idx)
        