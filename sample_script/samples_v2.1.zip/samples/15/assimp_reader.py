from OpenGL.GL import *
from OpenGL.GLU import *
import gl_util
import c_assimp

class AssimpReader:
    def __init__(self, model_file):
        self.model = c_assimp.Model()
        self.model.import_file(model_file)
        
    def create_vao(self):
        for mat in self.model.materials:
            mat.vao = glGenVertexArrays(1)
            glBindVertexArray(mat.vao)
            glEnableVertexAttribArray(0)
            glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_vertex)
            glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
            if mat.has_normal:
                glEnableVertexAttribArray(1)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_normal)
                glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, None)
            if mat.has_uv:
                glEnableVertexAttribArray(2)
                glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_tex_coord)
                glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, None)
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mat.ibo_faces)
            glBindBuffer(GL_ARRAY_BUFFER, 0)
            glBindVertexArray(0)
        
    def read_mesh(self):
        for mat in self.model.materials:
            # mesh
            mat.ibo_faces = gl_util.create_ibo(mat.faces)
            if mat.has_position:
                mat.vbo_vertex = gl_util.create_vbo(mat.vertexs)
            if mat.has_normal:
                mat.vbo_normal = gl_util.create_vbo(mat.normals)
            if mat.has_uv:
                mat.vbo_tex_coord = gl_util.create_vbo(mat.uvs)
            # texture
            if mat.texture_file:
                 mat.texture = gl_util.create_texture(mat.texture_file)
        # vao
        self.create_vao()
        
