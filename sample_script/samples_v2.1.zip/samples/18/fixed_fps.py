from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import gl_util

vert_pos = np.array([[0.0, 0.5, 0.0], [-0.5, -0.5, 0.0], [0.5, -0.5, 0.0]], dtype=np.float32)
program = None
pos_vbo = None

vertex_shader_src="""
#version 400 core

layout(location = 0) in vec3 position;

void main(void) {
    gl_Position = vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = vec4(1.0);
}
""".strip()

def init(window, width, height):
    global program, pos_vbo
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_vbo = gl_util.create_vbo(vert_pos)

def update(window, width, height):
    pass

def draw():
    glUseProgram(program)
    glEnableVertexAttribArray(0)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
    num_vertex = vert_pos.size // 3
    glDrawArrays(GL_TRIANGLES, 0, num_vertex)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

FPS = 60
REFRESH_SEC = 1.0 / FPS
previous_seconds = 0.0
previous_seconds_ = 0.0
frame_count = 0

def update_fps(window):
    global previous_seconds, frame_count
    current_seconds = glfw.get_time()
    elapsed_seconds = current_seconds - previous_seconds
    if elapsed_seconds > 0.25:
        previous_seconds = current_seconds
        fps = frame_count / elapsed_seconds
        tmp= "PyOpenGL Sample: FPS: {:.2f}".format(fps)
        glfw.set_window_title (window, tmp)
        frame_count = 0
    frame_count += 1

def wait_for_refresh_timing():
    global previous_seconds_
    while True:
        current_seconds = glfw.get_time()
        elapsed_seconds = current_seconds - previous_seconds_
        if elapsed_seconds >= REFRESH_SEC:
            previous_seconds_ = current_seconds
            break

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        update_fps(window)
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

        # 60 FPSを保つ
        wait_for_refresh_timing()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
