from PIL import Image, ImageDraw, ImageFont

text = """スコア: 00000010
ステージ: 01
"""
text_color = (0, 0, 0, 255)
bk_color = (255, 255, 255, 0)
font = ImageFont.truetype("msgothic.ttc", 24, encoding="utf-8")

def create_text_image(text, font, text_color, bk_color):
    # create image
    img = Image.new("RGBA", (1024, 256), bk_color)
    draw = ImageDraw.Draw(img)
    # draw text
    width = 0
    height = 0
    for line in text.splitlines():
        draw.text((0, height), line, font=font, fill=text_color)
        _, _, w, h = draw.textbbox((0, 0), line, font)
        width = max(w, width)
        height += h
    # trim extra margin of right and bottom
    return img.crop((0, 0, width, height))

if __name__ == "__main__":
    img = create_text_image(text, font, text_color, bk_color)
    img.show()
    img.save("text.png")
