from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import my_glm as glm
import gl_util

vert_pos = [
    [-0.5, 0.25,   0.0],   # 0
    [0.0,  0.25,   0.0],   # 1
    [0.5,  0.25,   0.0],   # 2
    [-0.5, -0.25,  0.0],   # 3
    [0.0,  -0.25,  0.0],   # 4
    [0.5,  -0.25,  0.0]],  # 5
vert_contour_value = [
    0.0,         # 0
    3.34709e+1,  # 1
    1.06832e+2,  # 2
    0.0,         # 3
    2.95168e+1,  # 4
    9.96408e+1]  # 5
color_code = np.array([
    [0.0, 0.0, 1.0, 1.0],   # 青
    [0.0, 1.0, 0.0, 1.0],   # 緑
    [1.0, 1.0, 0.0, 1.0],   # 黄
    [1.0, 0.0, 0.0, 1.0]],  # 赤
    dtype=np.float32)
tria_index = np.array([
    [0, 3, 4],
    [4, 1, 0],
    [1, 4, 5],
    [5, 2, 1]],
    dtype=np.uint32)
program = None
pos_vbo = None
tex_coord_vbo = None
texture_id = -1

vertex_shader_src="""
#version 400 core

layout(location = 0) in vec3 position;
layout(location = 1) in float texCoord;
out float outTexCoord;
uniform mat4 MVP;

void main(void) {
    outTexCoord = texCoord;
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in float outTexCoord;
out vec4 outFragmentColor;
uniform sampler1D textureUnit;

void main(void) {
    outFragmentColor = texture(textureUnit, outTexCoord);
}
""".strip()

def create_1D_texture(color_code):
    # テクスチャオブジェクトを作成
    texture = glGenTextures(1)
    # テクスチャオブジェクトをバインド
    glBindTexture(GL_TEXTURE_1D, texture)
    # アップロードされるデータがどのように整列されるかを OpenGL に通知します
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
    # データを転送します
    glTexImage1D(
        GL_TEXTURE_1D,        # ターゲットテクスチャを指定します
        0,                    # 詳細レベル番号を指定します。レベル0はベースイメージレベルです。レベル n は、n 番目のミップマップ縮小画像です
        GL_RGBA32F,
        color_code.shape[0],
        0,                    # ボーダー値です。この値は0でなければなりません
        GL_RGBA,
        GL_FLOAT,
        color_code)
    # テクスチャサンプリング/フィルタリング操作
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP)
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
    # バインドを解除します
    glBindTexture(GL_TEXTURE_1D, 0)
    return texture

def create_vetex_tex_coord(vert_contour_value):
    # 最小値と最大値を計算
    min_v = min(vert_contour_value)
    max_v = max(vert_contour_value)
    # 最小値から最大値を0.0から1.0にマッピング
    vert_tex_coord = [(v - min_v) / (max_v - min_v) for v in vert_contour_value]
    vert_tex_coord = np.array(vert_tex_coord, dtype=np.float32)
    return vert_tex_coord

def init(window, width, height):
    global program, pos_vbo, tex_coord_vbo, texture_id
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_vbo = gl_util.create_vbo(vert_pos)
    vert_tex_coord = create_vetex_tex_coord(vert_contour_value)
    tex_coord_vbo = gl_util.create_vbo(vert_tex_coord)
    # テクスチャを設定
    texture_id = create_1D_texture(color_code)
    sampler_loc = glGetUniformLocation(program, "textureUnit")
    glUseProgram(program)
    glUniform1i(sampler_loc, 0)
    glUseProgram(0)
    glActiveTexture(GL_TEXTURE0)
    glBindTexture(GL_TEXTURE_1D, texture_id)

def update(window, width, height):
    pass

def draw():
    glEnable(GL_TEXTURE_1D)
    glEnable(GL_DEPTH_TEST)
    glUseProgram(program)
    # MVP 行列を設定
    M = glm.mat4(1.0)
    V = glm.lookAt(glm.vec3(0.0, 0.0, 1.0),
        glm.vec3(0.0, 0.0, 0.0),
        glm.vec3(0.0, 1.0, 0.0))
    aspect_ratio = SCREEN_WIDTH / SCREEN_HEIGHT
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, -1.0, 1.0)
    P = np.array(P, dtype=np.float32)
    MVP = P * V * M
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    # 頂点属性を設定
    glEnableVertexAttribArray(0)
    glEnableVertexAttribArray(1)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, tex_coord_vbo)
    glVertexAttribPointer(1, 1, GL_FLOAT, GL_FALSE, 0, None)
    # 図形を描画
    num_vertex = tria_index.size
    glDrawElements(GL_TRIANGLES, num_vertex, GL_UNSIGNED_INT, tria_index)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glUseProgram(0)
    glDisable(GL_DEPTH_TEST)
    glDisable(GL_TEXTURE_1D)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
