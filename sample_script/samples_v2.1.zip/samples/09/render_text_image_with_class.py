from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
from PIL import ImageFont
import text_renderer

score = 0
text = "スコア: 000000000"
font_size = 24
text_color = (0, 0, 255, 255)
bk_color = (0, 0, 0, 0)
font = ImageFont.truetype("msgothic.ttc", 24, encoding="utf-8")
renderer = None

def init(window, width, height):
    global renderer
    renderer = text_renderer.text_renderer(text, font_size, text_color, bk_color, width, height)

def update(window, width, height):
    global score, text
    score += 1
    text = "スコア: {:0>9}".format(score)
    renderer.set_text(text)

def draw():
    renderer.draw_text(0, 0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()