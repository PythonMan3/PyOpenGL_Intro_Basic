from OpenGL.GL import *
import glfw
from PIL import Image
import numpy as np
import my_glm as glm
import gl_util

vertex = [
    -0.5, -0.5, # 頂点 0
    0.5, -0.5,  # 頂点 1
    0.5, 0.5,   # 頂点 2
    -0.5, 0.5]  # 頂点 3

face = [
    0, 1, 2,
    2, 3, 0]

tex_coords = [
    0.0, 1.0,  # 頂点 0
    1.0, 1.0,  # 頂点 1
    1.0, 0.0,  # 頂点 2
    0.0, 0.0]  # 頂点 3

png_file = "hebi.png"
program = None
vao = None
tex_loc = -1
texture = None

vertex_shader_src="""
#version 400 core

layout(location = 0) in vec2 position;
layout(location = 1) in vec2 textureCoord;
out vec2 vTextureCoord;
uniform mat4 P;

void main(void) {
    vTextureCoord = textureCoord;
    gl_Position = P * vec4(position, 0.0, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec2 vTextureCoord;
out vec4 outFragmentColor;
uniform sampler2D texture0;

void main(void) {
    outFragmentColor = texture(texture0, vTextureCoord);
}
""".strip()

def create_texture():
    texture = glGenTextures(1)
    glPixelStorei(GL_UNPACK_ALIGNMENT, 8)
    glBindTexture(GL_TEXTURE_2D, texture)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
    
    b = bytearray()
    b.extend(bytearray([255, 0, 0, 255]))      # 1行目 (赤)
    b.extend(bytearray([0, 255, 0, 255]))      # 1行目 (緑)
    b.extend(bytearray([0, 0, 255, 255]))      # 1行目 (青)
    b.extend(bytearray([0, 0, 0, 0]))
    b.extend(bytearray([255, 255, 0, 255]))    # 2行目 (黄)
    b.extend(bytearray([0, 255, 255, 255]))    # 2行目 (シアン)
    b.extend(bytearray([255, 0, 255, 255]))    # 2行目 (ピンク)
    b.extend(bytearray([0, 0, 0, 0]))
    b.extend(bytearray([255, 255, 255, 255]))  # 3行目 (白)
    b.extend(bytearray([128, 128, 128, 255]))  # 3行目 (グレー)
    b.extend(bytearray([64, 64, 64, 255]))     # 3行目 (濃いグレー)
    b.extend(bytearray([0, 0, 0, 0]))
    textureData = bytes(b)
    
    width = 3
    height = 3
    format = GL_RGBA
    glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, textureData)
    return texture

def init(window, width, height):
    global program, vao, tex_loc, texture
    texture = create_texture()
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    tex_loc = glGetUniformLocation(program, "texture0")
    position_vbo = gl_util.create_vbo(vertex)
    texCoord_vbo = gl_util.create_vbo(tex_coords)
    # create vao
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    glEnableVertexAttribArray(0)
    glBindBuffer(GL_ARRAY_BUFFER, position_vbo)
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, None)
    glEnableVertexAttribArray(1)
    glBindBuffer(GL_ARRAY_BUFFER, texCoord_vbo)
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)
    # set uniform for projection
    aspect_ratio = width / height
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, -1.0, 1.0)
    P = np.array(P, dtype=np.float32)
    P_loc = glGetUniformLocation(program, "P")
    glUseProgram(program)
    glUniformMatrix4fv(P_loc, 1, GL_FALSE, P)
    glUseProgram(0)

def update(window, width, height):
    pass

def draw():
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glEnable(GL_BLEND)
    glEnable(GL_TEXTURE_2D)
    glUseProgram(program)
    glBindVertexArray(vao)
    glActiveTexture(GL_TEXTURE0)
    glBindTexture(GL_TEXTURE_2D, texture)
    glUniform1i(tex_loc, 0)
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, face)
    glDisable(GL_TEXTURE_2D)
    glDisable(GL_BLEND)
    glBindVertexArray(0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
