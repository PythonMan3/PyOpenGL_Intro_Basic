from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import my_glm as glm
import gl_util

vert_pos = [
    [-1.0, 0.0, 0.0],  # 0
    [0.0, 0.0, 0.0],   # 1
    [-0.5, 1.0, 0.0],  # 2
    [1.0, 0.0, 0.0],   # 3
    [0.5, -1.0, 0.0]]  # 4
vert_color = [
    [1.0, 0.0, 0.0, 1.0],  # 0  (赤)
    [0.0, 1.0, 0.0, 1.0],  # 1  (緑)
    [0.0, 0.0, 1.0, 1.0],  # 2  (青)
    [1.0, 0.0, 0.0, 1.0],  # 3  (赤)
    [0.0, 0.0, 1.0, 1.0]]  # 4  (青)
program = None
pos_vbo = None
color_vbo = None
angle = 0.0

vertex_shader_src="""
#version 400 core

layout(location = 0) in vec3 position;
layout(location = 1) in vec4 color;
out vec4 outColor;
uniform mat4 MVP;

void main(void) {
    outColor = color;
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec4 outColor;
out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = outColor;
}
""".strip()

def init(window, width, height):
    global program, pos_vbo, color_vbo
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_vbo = gl_util.create_vbo(vert_pos)
    color_vbo = gl_util.create_vbo(vert_color)

def update(window, width, height):
    pass

def draw():
    global angle
    glUseProgram(program)
    glEnableVertexAttribArray(0)
    glEnableVertexAttribArray(1)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, color_vbo)
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0, None)
    # CCW
    elapsed_seconds = glfw.get_time()
    angle = 60.0 * elapsed_seconds % 360.0
    MVP_loc = glGetUniformLocation(program, "MVP")
    T = glm.translate(glm.mat4(), glm.vec3(0.5, 0.0, 0.0))
    R = glm.rotate(glm.mat4(), glm.radians(angle), glm.vec3(0.0, 1.0, 0.0))
    T2 = glm.translate(glm.mat4(), glm.vec3(-0.5, 0.0, 0.0))
    MVP = np.array(T2 * R * T, dtype=np.float32)
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    tria_index = np.array([0, 1, 2], dtype=np.uint32)
    num_vertex = tria_index.size
    glDrawElements(GL_TRIANGLES, num_vertex, GL_UNSIGNED_INT, tria_index)
    # CW
    MVP = np.array(T * R * T2, dtype=np.float32)
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    tria_index = np.array([1, 3, 4], dtype=np.uint32)
    num_vertex = tria_index.size
    glDrawElements(GL_TRIANGLES, num_vertex, GL_UNSIGNED_INT, tria_index)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
