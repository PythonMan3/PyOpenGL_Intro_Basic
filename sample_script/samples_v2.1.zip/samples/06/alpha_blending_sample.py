from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import my_glm as glm
import gl_util

vert_pos = [
    [-0.8, 0.0, 0.5],   # 0
    [-0.8, -0.8, 0.5],  # 1
    [0.0, -0.8, 0.5],   # 2
    [0.0, 0.0, 0.5],    # 3
    [-0.4, 0.4, 0.0],   # 4
    [-0.4, -0.4, 0.0],  # 5
    [0.4, -0.4, 0.0],   # 6
    [0.4, 0.4, 0.0],    # 7
    [0.0, 0.8, -0.5],   # 8
    [0.0, 0.0, -0.5],   # 9
    [0.8, 0.0, -0.5],   # 10
    [0.8, 0.8, -0.5]]   # 11
vert_color = [
    [1.0, 0.0, 0.0, 0.5],  # 0  (赤)
    [1.0, 0.0, 0.0, 0.5],  # 1  (赤)
    [1.0, 0.0, 0.0, 0.5],  # 2  (赤)
    [1.0, 0.0, 0.0, 0.5],  # 3  (赤)
    [0.0, 1.0, 0.0, 0.5],  # 4  (緑)
    [0.0, 1.0, 0.0, 0.5],  # 5  (緑)
    [0.0, 1.0, 0.0, 0.5],  # 6  (緑)
    [0.0, 1.0, 0.0, 0.5],  # 7  (緑)
    [0.0, 0.0, 1.0, 0.5],  # 8  (青)
    [0.0, 0.0, 1.0, 0.5],  # 9  (青)
    [0.0, 0.0, 1.0, 0.5],  # 10 (青)
    [0.0, 0.0, 1.0, 0.5]]  # 11 (青)
program = None
pos_vbo = None
color_vbo = None
pos_loc = -1
color_loc = -1

vertex_shader_src="""
#version 400 core

in vec3 position;
in vec4 color;
out vec4 outColor;
uniform mat4 MVP;

void main(void) {
    outColor = color;
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec4 outColor;
out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = outColor;
}
""".strip()

def init(window, width, height):
    global program, pos_vbo, color_vbo, pos_loc, color_loc
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_loc = glGetAttribLocation(program, "position")
    color_loc = glGetAttribLocation(program, "color")
    pos_vbo = gl_util.create_vbo(vert_pos)
    color_vbo = gl_util.create_vbo(vert_color)
    # set uniform for projection
    M = glm.mat4(1.0)
    V = glm.lookAt(glm.vec3(0.0, 0.0, 1.0),
        glm.vec3(0.0, 0.0, 0.0),
        glm.vec3(0.0, 1.0, 0.0))
    aspect_ratio = width / height
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, -1.0, 1.0)
    P = np.array(P, dtype=np.float32)
    MVP = P * V * M
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUseProgram(program)
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    glUseProgram(0)

def update(window, width, height):
    pass

def draw():
    glEnable(GL_DEPTH_TEST)
    glDepthFunc(GL_LESS)
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
    glUseProgram(program)
    glEnableVertexAttribArray(pos_loc)
    glEnableVertexAttribArray(color_loc)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, color_vbo)
    glVertexAttribPointer(color_loc, 4, GL_FLOAT, GL_FALSE, 0, None)
    # 赤い図形を描画
    tria_index = np.array([[0, 1, 2], [2, 3, 0]], dtype=np.uint32)
    num_vertex = tria_index.size
    glDrawElements(GL_TRIANGLES, num_vertex, GL_UNSIGNED_INT, tria_index)
    # 緑い図形を描画
    tria_index = np.array([[4, 5, 6], [6, 7, 4]], dtype=np.uint32)
    num_vertex = tria_index.size
    glDrawElements(GL_TRIANGLES, num_vertex, GL_UNSIGNED_INT, tria_index)
    # 青い図形を描画
    tria_index = np.array([[8, 9, 10], [10, 11, 8]], dtype=np.uint32)
    num_vertex = tria_index.size
    glDrawElements(GL_TRIANGLES, num_vertex, GL_UNSIGNED_INT, tria_index)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glUseProgram(0)
    glDisable(GL_DEPTH_TEST)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
