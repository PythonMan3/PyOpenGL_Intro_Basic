from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import my_glm as glm
import numpy as np
import gl_util

vertex = np.array([
    [-0.5, -0.5, -0.5],  # 0
    [-0.5, -0.5, 0.5],   # 1
    [-0.5, 0.5, 0.5],    # 2
    [-0.5, 0.5, -0.5],   # 3
    [0.5, -0.5, -0.5],   # 4
    [0.5, -0.5, 0.5],    # 5
    [0.5, 0.5, 0.5],     # 6
    [0.5, 0.5, -0.5]],   # 7
    dtype=np.float32)
face = np.array([
    [0, 1, 2],   # 左面
    [0, 2, 3],   # 左面
    [0, 3, 7],   # 後面
    [0, 7, 4],   # 後面
    [0, 4, 5],   # 下面
    [0, 5, 1],   # 下面
    [6, 5, 4],   # 右面
    [6, 4, 7],   # 右面
    [6, 7, 3],   # 上面
    [6, 3, 2],   # 上面
    [6, 2, 1],   # 前面
    [6, 1, 5]],  # 前面
    dtype=np.uint32)
edge = np.array([
    [0, 1],
    [1, 2],
    [2, 3],
    [3, 0],
    [4, 5],
    [5, 6],
    [6, 7],
    [7, 4],
    [0, 4],
    [1, 5],
    [3, 7],
    [2, 6]],
    dtype=np.uint32)
red_color = np.array([1.0, 0.0, 0.0], dtype=np.float32)
white_color = np.array([1.0, 1.0, 1.0], dtype=np.float32)
program = None
pos_vbo = None
face_ibo = None
edge_ibo = None
color_loc = -1

vertex_shader_src="""
#version 400 core

layout(location = 0) in vec3 position;
uniform mat4 MVP;

void main(void) {
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

uniform vec3 color;
out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = vec4(color, 1.0);
}
""".strip()

def init(window, width, height):
    global program, pos_vbo, face_ibo, edge_ibo, color_loc
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    pos_vbo = gl_util.create_vbo(vertex)
    face_ibo = gl_util.create_ibo(face)
    edge_ibo = gl_util.create_ibo(edge)
    color_loc = glGetUniformLocation(program, "color")
    # View
    V = glm.lookAt(glm.vec3(3.0, 4.0, 5.0,),
        glm.vec3(0.0, 0.0, 0.0),
        glm.vec3(0.0, 1.0, 0.0))
    # Projection
    ratio = width / height
    P = glm.ortho(-ratio, ratio, -1.0, 1.0, 1.0, 10.0)
    MVP = np.array(P * V, dtype=np.float32)
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUseProgram(program)
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    glUseProgram(0)

def update(window, width, height):
    pass

def draw():
    glEnable(GL_DEPTH_TEST)
    glUseProgram(program)
    glEnableVertexAttribArray(0)
    # draw face
    glUniform3fv(color_loc, 1, red_color)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, None)
    num_vertex = face.size  # 36
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, face_ibo)
    glDrawElements(GL_TRIANGLES, num_vertex, GL_UNSIGNED_INT, None)
    # draw edge
    glUniform3fv(color_loc, 1, white_color)
    num_vertex = edge.size  # 24
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, edge_ibo)
    glDrawElements(GL_LINES, num_vertex, GL_UNSIGNED_INT, None)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0)
    glUseProgram(0)
    glDisable(GL_DEPTH_TEST)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
