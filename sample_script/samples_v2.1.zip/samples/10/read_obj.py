from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import my_glm as glm
import numpy as np
import gl_util
from obj_mesh import ObjMesh

vertex_shader_src="""
#version 400 core

in vec3 position;
in vec3 normal;
in vec2 texCoord;
out vec3 outNormal;
out vec2 outTextureCoord;
uniform mat4 MVP;

void main(void) {
    outNormal = normal;
    outTextureCoord = texCoord;
    gl_Position = MVP * vec4(position, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec3 outNormal;
in vec2 outTextureCoord;
out vec4 outFragmentColor;
uniform sampler2D texture0;
uniform vec3 invLight;
uniform int hasTexture;

void main(void) {
    float diffuse = max(dot(outNormal, invLight), 0.0);
    vec4 color = texture(texture0, outTextureCoord);
    if (bool(hasTexture)) {
        outFragmentColor = vec4(color.r * diffuse, color.g * diffuse, color.b * diffuse, 1.0);
    } else {
        outFragmentColor = vec4(1.0);
    }
}
""".strip()

program = None
obj = None
light_dir_vec = [3.0, 4.0, 5.0]
aspect_ratio = 1.0
angle = 0.0
prev_time = 0.0

def init(window, width, height):
    global aspect_ratio, program, obj
    aspect_ratio = width / height
    obj = ObjMesh("data/box-T2F_N3F_V3F.obj")
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    glUseProgram(program)
    # texture
    tex_loc = glGetUniformLocation(program, "texture0")
    glUniform1i(tex_loc, 0)
    glUseProgram(0)

def update(window, width, height):
    pass

def draw_obj(obj):
    # アトリビュート変数を有効化
    pos_loc = glGetAttribLocation(program, "position")
    glEnableVertexAttribArray(pos_loc)
    if obj.has_norm:
        normal_loc = glGetAttribLocation(program, "normal")
        glEnableVertexAttribArray(normal_loc)
    if obj.has_uv:
        tex_coord_loc = glGetAttribLocation(program, "texCoord")
        glEnableVertexAttribArray(tex_coord_loc)
        glEnable(GL_TEXTURE_2D)
    # 座標バッファオブジェクトの位置を指定
    for mat in obj.materials:
        glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_vertex)
        glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
        if obj.has_norm:
            glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_normal)
            glVertexAttribPointer(normal_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
        if obj.has_uv:
            glBindTexture(GL_TEXTURE_2D, mat.texture)
            glBindBuffer(GL_ARRAY_BUFFER, mat.vbo_tex_coord)
            glVertexAttribPointer(tex_coord_loc, 2, GL_FLOAT, GL_FALSE, 0, None)
        if mat.texture:
            glActiveTexture(GL_TEXTURE0)
            glBindTexture(GL_TEXTURE_2D, mat.texture)
        num_vertex = len(mat.vertices) // 3
        glDrawArrays(GL_TRIANGLES, 0, num_vertex)
    glDisableVertexAttribArray(pos_loc)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    if obj.has_norm:
        glDisableVertexAttribArray(normal_loc)
    if obj.has_uv:
        glDisableVertexAttribArray(tex_coord_loc)
        glDisable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, 0)

def draw():
    global angle, prev_time
    glEnable(GL_DEPTH_TEST)
    glUseProgram(program)
    # MVP matrix
    elapsed_seconds = glfw.get_time() - prev_time
    prev_time = glfw.get_time()
    angle = (angle + glm.radians(60.0 * elapsed_seconds)) % 360.0
    M = glm.rotate(glm.mat4(1.0), angle, glm.vec3(0.0, 1.0, 0.0))
    V = glm.lookAt(glm.vec3(5.0, 6.0, 7.0),
        glm.vec3(0.0, 0.0, 0.0),
        glm.vec3(0.0, 1.0, 0.0))
    size = 2.0
    P = glm.ortho(-aspect_ratio*size, aspect_ratio*size, -1.0*size, 1.0*size, -1.0, 100.0)
    MVP = np.array(P * V * M, dtype=np.float32)
    MVP_loc = glGetUniformLocation(program, "MVP")
    glUniformMatrix4fv(MVP_loc, 1, GL_FALSE, MVP)
    # invLight
    light_dir_vec_norm = glm.normalize(glm.vec3(light_dir_vec))
    invM = glm.inverse(M)
    invLight = glm.normalize((invM * glm.vec4(light_dir_vec_norm, 1.0)).xyz)
    invLight = np.array(invLight, dtype=np.float32)
    inv_light_loc = glGetUniformLocation(program, "invLight")
    glUniform3fv(inv_light_loc, 1, invLight)
    # hasTexture
    has_tex_loc = glGetUniformLocation(program, "hasTexture")
    glUniform1i(has_tex_loc, 1 if obj.has_uv else 0)
    draw_obj(obj)
    glUseProgram(0)
    glDisable(GL_DEPTH_TEST)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
