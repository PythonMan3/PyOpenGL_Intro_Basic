import gl_util
import pywavefront

class Material:
    def __init__(self):
        self.vertices = []
        self.normals = []
        self.tex_coords = []
        self.vbo_vertex = None
        self.vbo_normal = None
        self.vbo_tex_coord = None
        self.texture = 0
        
    def get_vertices(self):
        return self.vertices
        
    def get_normals(self):
        return self.normals
        
    def get_tex_coords(self):
        return self.tex_coords
        
class ObjMesh:
    def __init__(self, obj_file):
        self.obj_file = obj_file
        self.scene = pywavefront.Wavefront(obj_file)
        self.has_norm = False
        self.has_uv = False
        self.materials = []
        self.init_data()
        
    def has_norm(self):
        return self.has_norm
        
    def has_uv(self):
        return self.has_uv
        
    def init_data(self):
        for name, material in self.scene.materials.items():
            mat = Material()
            self.materials.append(mat)
            format = material.vertex_format
            vert_offset = 0
            norm_offset = 0
            tex_offset = 0
            next_offset = 0
            if format == "T2F_N3F_V3F":
                vert_offset = 5
                norm_offset = 2
                tex_offset = 0
                next_offset = 8
                self.has_norm = True
                self.has_uv = True
            elif format == "V3F":
                vert_offset = 0
                norm_offset = 0
                tex_offset = 0
                next_offset = 3
            else:
                raise NotImplementedError("Not supported obj type.")
            verts = []
            norms = []
            tex_crds = []
            all_verts = material.vertices
            count = len(all_verts)
            idx = 0
            while idx < count:
                verts.append(all_verts[idx + vert_offset])
                verts.append(all_verts[idx + vert_offset + 1])
                verts.append(all_verts[idx + vert_offset + 2])
                if self.has_norm:
                    norms.append(all_verts[idx + norm_offset])
                    norms.append(all_verts[idx + norm_offset + 1])
                    norms.append(all_verts[idx + norm_offset + 2])
                if self.has_uv:
                    tex_crds.append(all_verts[idx + tex_offset])
                    tex_crds.append(1.0 - all_verts[idx + tex_offset + 1])
                idx += next_offset
            # texture
            if material.texture:
                texture_file_path = material.texture.path
                mat.texture = gl_util.create_texture(texture_file_path)
            elif material.texture_alpha:
                texture_file_path = material.texture_alpha.path
                mat.texture = gl_util.create_texture(texture_file_path)
            mat.vertices = verts
            mat.vbo_vertex = gl_util.create_vbo(mat.vertices)
            if self.has_norm:
                mat.normals = norms
                mat.vbo_normal = gl_util.create_vbo(mat.normals)
            if self.has_uv:
                mat.tex_coords = tex_crds
                mat.vbo_tex_coord = gl_util.create_vbo(mat.tex_coords)
