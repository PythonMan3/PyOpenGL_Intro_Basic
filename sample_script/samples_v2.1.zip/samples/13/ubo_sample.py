from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
import my_glm as glm
import gl_util
from ctypes import *

vert_pos = np.array([[0.0, 0.5, 0.0], [-0.5, -0.5, 0.0], [0.5, -0.5, 0.0]], dtype=np.float32)
program = None
other_program = None
vao = None
model_ubo = None
other_vao = None
model_x = -0.5

vertex_shader_src="""
#version 400 core

in vec3 position;
out vec4 outColor;

layout (std140) uniform model
{
    mat4 mvpMatrix;
    vec4 color;
};

void main(void) {
    outColor = color;
    gl_Position = mvpMatrix * vec4(position, 1.0);
}
""".strip()

other_vertex_shader_src="""
#version 400 core

in vec3 position;
out vec4 outColor;

layout (std140) uniform model
{
    mat4 mvpMatrix;
    vec4 color;
};

void main(void) {
    outColor = vec4(0.0, 0.0, 1.0, 1.0);
    gl_Position = mvpMatrix * vec4(position.x + 1.0, position.y, position.z, 1.0);
}
""".strip()

fragment_shader_src="""
#version 400 core

in vec4 outColor;
out vec4 outFragmentColor;

void main(void) {
    outFragmentColor = outColor;
}
""".strip()

def create_vao(vert_pos, program):
    pos_vbo = gl_util.create_vbo(vert_pos)
    pos_loc = glGetAttribLocation(program, "position")
    # VAO を作成
    vao = glGenVertexArrays(1)
    glBindVertexArray(vao)
    glEnableVertexAttribArray(pos_loc)
    glBindBuffer(GL_ARRAY_BUFFER, pos_vbo)
    glVertexAttribPointer(pos_loc, 3, GL_FLOAT, GL_FALSE, 0, None)
    glBindBuffer(GL_ARRAY_BUFFER, 0)
    glBindVertexArray(0)
    return vao

def create_ubo(model):
    if not isinstance(model, np.ndarray):
        model = np.array(model, dtype=np.float32)
    ubo = glGenBuffers(1)
    glBindBuffer(GL_UNIFORM_BUFFER, ubo)
    glBufferData(GL_UNIFORM_BUFFER, model.nbytes, model, GL_DYNAMIC_DRAW)
    glBindBuffer(GL_UNIFORM_BUFFER, 0)
    return ubo

def init(window, width, height):
    global program, vao, other_program, other_vao, model_ubo
    program = gl_util.create_program(vertex_shader_src, fragment_shader_src)
    vao = create_vao(vert_pos, program)
    other_program = gl_util.create_program(other_vertex_shader_src, fragment_shader_src)
    other_vao = create_vao(vert_pos, other_program)
    # UBO を作成
    M = glm.translate(glm.mat4(), glm.vec3(model_x, 0.0, 0.0))
    aspect_ratio = width / height
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, -1.0, 1.0)
    mvpMatrix = np.array(P * M, dtype=np.float32)
    color = np.array([1.0, 0.0, 0.0, 1.0], dtype=np.float32)
    model = np.append(mvpMatrix, color)
    model_ubo = create_ubo(model)
    # UBO をバインド
    blockIndexModel = glGetUniformBlockIndex(program, 'model')
    glUniformBlockBinding(program, blockIndexModel, 0)
    blockIndexModel = glGetUniformBlockIndex(other_program, 'model')
    glUniformBlockBinding(other_program, blockIndexModel, 0)
    glBindBufferBase(GL_UNIFORM_BUFFER, 0, model_ubo)

def update_ubo(model):
    if not isinstance(model, np.ndarray):
        model = np.array(model, dtype=np.float32)
    glBindBuffer(GL_UNIFORM_BUFFER, model_ubo)
    if True:
        glBufferSubData(GL_UNIFORM_BUFFER, 0, model.nbytes, model)
    else:
        map_data = glMapBuffer(GL_UNIFORM_BUFFER, GL_WRITE_ONLY)
        map_array = (GLfloat * model.size).from_address(map_data)
        map_array[:] = model[:]
        glUnmapBuffer(GL_UNIFORM_BUFFER)
    glBindBuffer(GL_UNIFORM_BUFFER, 0)

def update(window, width, height):
    # UBO を更新
    elapsed_seconds = glfw.get_time()
    offset_x = 1.0 * elapsed_seconds % 1.0
    new_model_x = model_x + offset_x
    M = glm.translate(glm.mat4(), glm.vec3(new_model_x, 0.0, 0.0))
    aspect_ratio = width / height
    P = glm.ortho(-aspect_ratio, aspect_ratio, -1.0, 1.0, -1.0, 1.0)
    mvpMatrix = np.array(P * M, dtype=np.float32)
    color = np.array([1.0, 0.0, 0.0, 1.0], dtype=np.float32)
    model = np.append(mvpMatrix, color)
    update_ubo(model)

def draw():
    # モデルを描画
    glUseProgram(program)
    glBindVertexArray(vao)
    num_vertex = vert_pos.size // 3
    glDrawArrays(GL_TRIANGLES, 0, num_vertex)
    glBindVertexArray(0)
    glUseProgram(0)
    # もう一つのモデルを描画
    glUseProgram(other_program)
    glBindVertexArray(other_vao)
    num_vertex = vert_pos.size // 3
    glDrawArrays(GL_TRIANGLES, 0, num_vertex)
    glBindVertexArray(0)
    glUseProgram(0)

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
