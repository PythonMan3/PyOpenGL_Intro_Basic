from OpenGL.GL import *
from OpenGL.GLU import *
import glfw
import numpy as np
from ctypes import *

vertex_shader_src="""
#version 400 core

layout (std140) uniform ublock {
    float uniform1;
    vec3 uniform2;
    vec4 uniform3;
};

void main(void) {
    gl_Position = vec4(1.0);
}
""".strip()

def create_program(vertex_shader_src):
    vertex_shader = glCreateShader(GL_VERTEX_SHADER)
    glShaderSource(vertex_shader, vertex_shader_src)
    glCompileShader(vertex_shader)
    result = glGetShaderiv(vertex_shader, GL_COMPILE_STATUS)
    if not result:
        err_str = glGetShaderInfoLog(vertex_shader).decode('utf-8')
        raise RuntimeError(err_str)
        glDeleteShader(vertex_shader)

    program = glCreateProgram()
    glAttachShader(program, vertex_shader)
    glDeleteShader(vertex_shader)
    glLinkProgram(program)
    result = glGetProgramiv(program, GL_LINK_STATUS)
    if not result:
        err_str = glGetProgramInfoLog(program).decode('utf-8')
        raise RuntimeError(err_str)

    return program

def init(window, width, height):
    program = create_program(vertex_shader_src)
    
    uniform_names = ["uniform1", "uniform2", "uniform3"]
    name_array = c_char_p * len(uniform_names)
    c_uniform_names = name_array(*[c_char_p(name.encode()) for name in uniform_names])
    c_uniform_names = cast(c_uniform_names, POINTER(POINTER(c_char)))
    indices = np.zeros(len(uniform_names), dtype=np.uint32)
    glGetUniformIndices(program, len(uniform_names), c_uniform_names, indices)
    
    offset = (c_uint32 * len(uniform_names))()
    glGetActiveUniformsiv(program, len(uniform_names), indices, GL_UNIFORM_OFFSET, offset)
    offset = np.frombuffer(offset, dtype=np.uint32)
    print(offset)

def update(window, width, height):
    pass

def draw():
    pass

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

def main():
    if not glfw.init():
        return

    window = glfw.create_window(SCREEN_WIDTH, SCREEN_HEIGHT, "PyOpenGL Sample", None, None)
    if not window:
        glfw.terminate()
        print('Failed to create window')
        return

    glfw.make_context_current(window)

    glfw.window_hint(glfw.CONTEXT_VERSION_MAJOR, 4)
    glfw.window_hint(glfw.CONTEXT_VERSION_MINOR, 0)
    glfw.window_hint(glfw.OPENGL_PROFILE, glfw.OPENGL_CORE_PROFILE)

    init(window, SCREEN_WIDTH, SCREEN_HEIGHT)

    while not glfw.window_should_close(window):
        glClearColor(0, 0, 0, 1)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        update(window, SCREEN_WIDTH, SCREEN_HEIGHT)
        draw()

        glfw.swap_buffers(window)

        glfw.poll_events()

    glfw.destroy_window(window)
    glfw.terminate()

if __name__ == "__main__":
    main()
